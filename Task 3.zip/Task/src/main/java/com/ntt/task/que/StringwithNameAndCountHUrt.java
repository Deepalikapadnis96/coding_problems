package com.ntt.task.que;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import lombok.val;

public class StringwithNameAndCountHUrt {
//string with num of time is been wrng
	public static void main(String[] args) {
		Map<String, ArrayList<String>>  names = new HashMap<>();
		ArrayList<String> pawar = new ArrayList<>();
		pawar.add("unlimited");
		names.put("pawar", pawar);
		ArrayList<String> i = new ArrayList<>();
		i.add("upto 10 times");
		names.put("i", i);
		for (Map.Entry<String, ArrayList<String>> entry : names.entrySet()) {
			String key = entry.getKey();
			ArrayList<String> value = entry.getValue();
			System.out.println(" names of plps :" + key +  value);
		}

	}
}
