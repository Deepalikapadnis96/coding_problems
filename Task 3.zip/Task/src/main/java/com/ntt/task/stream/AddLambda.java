package com.ntt.task.stream;

interface Addable{
	int add(int a, int b);
}

public class AddLambda {
public static void main(String[] args) {
	Addable ad = (a,b) ->(a+b);
	System.out.println(ad.add(8, 8));
}
}
