package com.ntt.task.stream;

public class main {
	public static void main(String[] args) {
		long cnumber = 4440967484181607L;
		System.out.println(cnumber + " is " + (validitychk(cnumber) ? "valid" : "invalid"));
	}

	public static boolean validitychk(long cnumber) {
		
		System.out.println("digit should be between 13 and 16 "); 

		
		return (thesize(cnumber) >= 13 && thesize(cnumber) <= 16) && (prefixmatch(cnumber, 4) || prefixmatch(cnumber, 5)
				|| prefixmatch(cnumber, 37) || prefixmatch(cnumber, 6))
				&& ((sumdoubleeven(cnumber) + sumodd(cnumber)) % 10 == 0);
			
		//return true;
		
	}

	public static int sumdoubleeven(long cnumber) {
		int sum = 0;
		String num = cnumber + "";
		for (int i = thesize(cnumber) - 2; i >= 0; i -= 2)
			sum += getDigit(Integer.parseInt(num.charAt(i) + "") * 2);
		System.out.println(cnumber);

		return sum;
	}

	public static int getDigit(int cnumber) {
		if (cnumber < 9)
			
			return cnumber;
		System.out.println(cnumber);

		return cnumber / 10 + cnumber % 10;

	}

	public static int sumodd(long cnumber) {
		int sum = 0;
		String num = cnumber + "";
		for (int i = thesize(cnumber) - 1; i >= 0; i -= 2)
			sum += Integer.parseInt(num.charAt(i) + "");
		System.out.println(cnumber + sum);

		return sum;
	}

	public static boolean prefixmatch(long cnumber, int d) {

		return getprefx(cnumber, thesize(d)) == d;
	}

	public static int thesize(long d) {
		String num = d + "";
		return num.length();
		
	}

	public static long getprefx(long cnumber, int k) {
		if (thesize(cnumber) > k) {
			String num = cnumber + "";
			return Long.parseLong(num.substring(0, k));
		}
		return cnumber;
	}
}
