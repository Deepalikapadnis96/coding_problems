package com.ntt.task;

public class StringTrim {
//This method removes all the trailing spaces so the length of the string also reduces.
	public static void main(String[] args) {
		String s1 = "  deepali kapadnis   ";
		System.out.println("without:: " + s1.length());

		System.out.println("with::" + s1.trim().length());
		// System.out.println(tr); // With trim()
	}

}
