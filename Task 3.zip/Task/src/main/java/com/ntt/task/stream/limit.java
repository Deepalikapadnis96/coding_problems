package com.ntt.task.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class limit {
public static void main(String[] args) {
	List<Integer> numbers = new ArrayList<>();
	
	numbers.add(2);
	numbers.add(4);
	numbers.add(6);
	numbers.add(8);
	numbers.add(10);
	numbers.add(12);
	numbers.add(14);
	numbers.add(16);
	
	Stream<Integer> stream = numbers.stream();
	List<Integer> limit4 = stream.limit(4) 
			.collect(Collectors.toList());
	System.out.println("limit upto 4 :");
	limit4.forEach(value -> System.out.println(value));


}
}
