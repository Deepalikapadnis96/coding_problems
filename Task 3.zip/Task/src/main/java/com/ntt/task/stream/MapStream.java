package com.ntt.task.stream;
import java.util.*;
public class MapStream {
	public static void main(String[] arg)
	{
		System.out.println("stream apply :");
		List<Integer> list = Arrays.asList(2,4,6);
		list.stream()
		.map(number -> number*3)
		.forEach(System.out::println);
	}

}
