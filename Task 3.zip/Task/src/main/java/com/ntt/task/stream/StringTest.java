package com.ntt.task.stream;

public class StringTest {
public static void main(String[] args) {
	String s1 = "deepali";
	System.out.println(s1);
}
}
