package com.ntt.task;

public class StringSplit {

	public static void main(String[] args) {
		String data = "ntt data payment services.mumbai";
		String[] word = data.split("\\s");// splits the string based on whitespace
		String[] words1 = data.split("e", 0);
		for (String words : words1) {
			System.out.println(words);
		}
	}

}
