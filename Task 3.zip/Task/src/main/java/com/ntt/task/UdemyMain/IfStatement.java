package com.ntt.task.UdemyMain;

public class IfStatement {
	public static void main(String[] args) {
		puzzle1();
		puzzle2();
		puzzle3();
	}

	public static void puzzle1() {
		int i = 9;

		if (i == 8) {
			System.out.println("i = 8");
		} else if (i == 4) {
			System.out.println("i = 4");
		} else if ((i != 8) && (i != 4)) {
			System.out.println("i != 8 and i != 4");

		}
	}

	public static void puzzle2() {
		int k = 88;

		if (k == 10) {
			System.out.println("is 10");
		} else if (k < 55) {
			System.out.println("is less then 55");

		} else if (k > 22) {
			System.out.println("greater than 22");

		}
	}

	public static void puzzle3() {
		int a = -9;
		if (a < 0) {
			a = a + 10;
		}
		a++;
		System.out.println(a);
	}

}
