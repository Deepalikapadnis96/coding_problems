package com.ntt.task.stream;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class log {

	public static void main(String args[]) {
		try {
			FileInputStream file1 = new FileInputStream("E:\\Files\\" + "catalina.2022-07-06.log");
			BufferedReader br = new BufferedReader(new InputStreamReader(file1));
			String strLine;
			while ((strLine = br.readLine()) != null) {
				System.out.println(strLine);
				String oneLine[] = strLine.split(" ");
				for (int j = 0; j < oneLine.length; j++) {

					if (Pattern.matches("(([A-Z].*[0-9])|([0-9].*[A-Z]))", oneLine[j])
							|| Pattern.matches("[0-9]+", oneLine[j])) {

						if (oneLine[j].length() <= 19 && oneLine[j].length() >= 11) {
							System.out.println("length is greater than 11 and less than 19 " + oneLine[j]);
							boolean flag = isValidCardNumber(oneLine[j].replaceAll("[a-zA-Z]", ""));

							if (flag) {
								System.out.println("CARD NUMBER IS TRUE");

							} else {
								System.out.println("CARD NUMBER IS FASLE");
							}
						} else {
							System.out.println("Length of number is greater or smaller than required " + oneLine[j]);
						}

					}

				}
			}
			file1.close();
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
		}

	}

	private static boolean isValidCardNumber(String cardNumber) {
		System.out.println("cardNumber " + cardNumber);
		int[] creditCardInt = new int[cardNumber.length()];
		for (int i = 0; i < cardNumber.length(); i++) {
			creditCardInt[i] = Integer.parseInt(cardNumber.substring(i, i + 1));
		}
		for (int i = creditCardInt.length - 2; i >= 0; i = i - 2) {
			int tempValue = creditCardInt[i];
			tempValue = tempValue * 2;
			if (tempValue > 9) {
				tempValue = tempValue % 10 + 1;

			}
			creditCardInt[i] = tempValue;
		}
		int total = 0;
		for (int i = 0; i < creditCardInt.length; i++) {
			total += creditCardInt[i];
		}
		// div by 10
		if (total % 10 == 0) {
			return true;
		} else {
			return false;

		}

	}

}
