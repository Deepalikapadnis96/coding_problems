package com.ntt.task.stream;

public class ValidateCreditCard {
	public static void main(String[] args) {
		String cardNumber = "4012888888881881111";
		//boolean result1 = cardNumber.matches("[0-9]+");

		boolean result = cardNumber.matches("(([A-Z].*[0-9])|([0-9].*[A-Z]))");
		//String line[] = cardNumber.split(" ");

		System.out.println("Original String : " + cardNumber);
		//System.out.println("Does string contain only Digits? : " + result1);
		System.out.println("Does string contain only Digits? : " + result);

		boolean validCardNumber = isValidCardNumber(cardNumber);
		if (validCardNumber) {
		System.out.println(cardNumber + "valid");
		} else {
			System.out.println(cardNumber + "Notvalid");

		}}
		/*
		String firstname1 = "4012888888881881AbC126ABC";
		int len = firstname1.length();
		int startindex=0;
		int endindex=firstname1.length();
		for(int i=0;i<len;i++) {
			System.out.println(Character
	                .isLetter(firstname1.charAt(i)) + "-" +firstname1.charAt(i));
			if (Character
	                .isLetter(firstname1.charAt(i))) {
				startindex=startindex+i;
	               System.out.println(firstname1.charAt(i)); 
	            }
			else {
				break;
			}
		}
		for(int i=len-1;i>=0;i--) {
			System.out.println(Character
	                .isLetter(firstname1.charAt(i)) + "-" +firstname1.charAt(i));
			if (Character
	                .isLetter(firstname1.charAt(i))) {
				endindex=endindex-1;
				System.out.println(firstname1.charAt(i));
	            }
			else {
				break;
			}
		}
		System.out.println(startindex);
		System.out.println(endindex-1);
		System.out.println(firstname1.substring(startindex, endindex));
//	    firstname1 = firstname1.replaceAll("[a-zA-Z]","");
//	    System.out.println(firstname1);//Prints Sam
	}
*/
	private static boolean isValidCardNumber(String cardNumber) {

		int[] creditCardInt = new int[cardNumber.length()];
		for (int i = 0; i < cardNumber.length(); i++) {

			creditCardInt[i] = Integer.parseInt(cardNumber, i+ 9);
			
					//parseInt(cardNumber.substring(i, i + 1));
					
					//parseInt(cardNumber.substring(i, i + 1));
		}
		for (int i = creditCardInt.length - 2; i >= 0; i = i - 2) {
			int tempValue = creditCardInt[i];
			tempValue = tempValue * 2;
			if (tempValue > 9) {
				tempValue = tempValue % 10 + 1;

			}
			creditCardInt[i] = tempValue;
		}
		int total = 0;
		for (int i = 0; i < creditCardInt.length; i++) {
			total += creditCardInt[i];
		}
		// mult by 10
		if (total % 10 == 0) {
			return true;
		} else {
			return false;

		}
	}
}
