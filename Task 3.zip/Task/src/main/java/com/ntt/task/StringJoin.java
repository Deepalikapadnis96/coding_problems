package com.ntt.task;

public class StringJoin {

	public static void main(String[] args) {
		System.out.println(String.join("-", "deepali", "kapadnis"));
	}

}
