package com.ntt.task.Udemy.ObjectOrientedProgramming;

public class MyChar {
	private char ch;

	public MyChar(char ch) {
		// TODO Auto-generated constructor stub
		this.ch = ch;
	}

	public boolean isVowel() {
		// TODO Auto-generated method stub
		if ((ch == 'a') || (ch == 'e') || (ch == 'i') || (ch == 'o') || (ch == 'u')) {
			return true;
		}

		return false;

	}

	public boolean isDigit() {
		// TODO Auto-generated method stub
		if ((ch >= 0) && (ch <= 9)) {
			return true;
		}
		return false;
	}

	public boolean isAlphabate() {
		// TODO Auto-generated method stub
		if ((ch >= 'a') && (ch <= 'z')) {
			return true;
		}
		return false;
	}

	public boolean isConsonant() {
		// TODO Auto-generated method stub
		if (!(ch == 'a') || (ch == 'e') || (ch == 'i') || (ch == 'o') || (ch == 'u')) {
			return true;
		}

		return false;

	}
}
