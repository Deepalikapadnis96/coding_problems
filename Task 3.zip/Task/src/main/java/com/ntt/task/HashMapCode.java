package com.ntt.task;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HashMapCode {
	/**
	 * taking string(key) and list of string(multiple values)
	 */
	public static void main(String[] args) {
//string name, list num of services
		Map<String, ArrayList<String>> employeeData = new HashMap();

		ArrayList<String> deepaliList = new ArrayList<String>();
		deepaliList.add("merchant jar");
		deepaliList.add("bvs");
		deepaliList.add("verify txn");
		employeeData.put("Deepali", deepaliList);

		ArrayList<String> surajList = new ArrayList<String>();
		surajList.add("pps");
		surajList.add("emitra");
		surajList.add("mgalla");

		employeeData.put("Suraj", surajList);

		if (employeeData.containsKey("Deepali")) {
			ArrayList<String> arrayList = employeeData.get("Deepali");
			arrayList.add("otsclient");
		}
		if (employeeData.containsKey("Deepali")) {
			ArrayList<String> arrayList = employeeData.get("Deepali");
			if (arrayList.contains("otsclient")) {
				System.out.println("otsclient is present");
			} else {
				System.out.println("otsclient is not present");
			}
		}
		
		for (Map.Entry<String, ArrayList<String>> entry : employeeData.entrySet()) {
			String key = entry.getKey();
			ArrayList<String> value = entry.getValue();
			System.out.println("employeName: " + key + value);
		}
	}
}
