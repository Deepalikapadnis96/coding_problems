package com.ntt.task;

public class Crypt {
public static void main(String[] args) {
	String message="DEEPALI KAPADNIS";
	String alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	String replace="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	String genCrypt = genCrypt(message, alpha, replace);
	System.out.println("crypt::"+ genCrypt);
}
	
	
	
	public static String genCrypt(String msg, String alpha, String replace) {
		StringBuilder stringBuilder = new StringBuilder();
		for (char c: msg.toCharArray()) {
			if(Character.isLetter(c)) {
				int index= alpha.indexOf(Character.toUpperCase(c));
				if(index !=-1) {
					stringBuilder.append(replace.charAt(index));
					
				}else {
					stringBuilder.append(c);
				}
			}else {
				stringBuilder.append(c);

			}
		}
		return stringBuilder.toString();
	}
}
