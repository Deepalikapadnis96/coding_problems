package com.ntt.task.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class reduce {
	public static void main(String[] args) {
		List<String> words = Arrays.asList("Deepali", "pooja", "nilima");

		/*---longest---*/

		Optional<String> longestString = words.stream()
				.reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2);
		longestString.ifPresent(System.out::println);

		/*-----Combine-------*/
		String[] array = { "deepali", "nimba", "kapadnis" };
		Optional<String> String_combine = Arrays.stream(array).reduce((str1, str2) -> str1 + "-" + str2);
		if (String_combine.isPresent()) {
			System.out.println(String_combine.get());

			/*------Sum-----*/
			List<Integer> array1 = Arrays.asList(-2, 0, 4, 6, 8);
			int sum = array1.stream().reduce(4, (ele1, ele2) -> ele1 + ele2);
			System.out.println("sum of all ele " + sum);
		}
	}
}
