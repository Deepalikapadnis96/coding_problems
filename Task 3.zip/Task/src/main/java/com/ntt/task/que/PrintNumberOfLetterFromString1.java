package com.ntt.task.que;

public class PrintNumberOfLetterFromString1 {
	public static void main(String[] args) {
		String data = "deepali kapadnis";
		int countdata = countdata(data);
		System.out.println("num of letters" + countdata);

	}

	public static int countdata(String str) {
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			if (Character.isLetter(str.charAt(i))) {
				count++;
			}
		}
		return count;
	}
}
