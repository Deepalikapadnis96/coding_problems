package com.ntt.task.stream;


public class Sum {

	public int sum(int a, int b) {
		int sum = a + b;
		System.out.println("The sum of numbers is: " + sum);
		return sum;
	}

		public void main (String arg[]) {
			
			Sum Obj =new Sum();

			
			
			int total= Obj.sum(20, 20);
			System.out.println("The sum of a and b is: " + total);


		}
	}


