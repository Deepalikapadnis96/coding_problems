package com.ntt.task.stream;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Sort {
		static List<User> users = Arrays.asList(
				new User("A",50),
				new User("B",40),
				new User("C",15),
				new User("D",8),
				new User("E",25));

				
				public static void main(String[] args) {

		/*
		 * List<String> list = Arrays.asList("8","D","E","E","i","4", "a","2", "p",
		 * "0","L"); List<String> sortedList = list.stream() .sorted()
		 * .sorted(Comparator.reverseOrder()) .collect(Collectors.toList());
		 * sortedList.forEach(System.out::println);
		 */
					
					List<User> sortedList = users.stream()
							.sorted(Comparator.comparingInt(User::getAge))
							.collect(Collectors.toList());
					sortedList.forEach(System.out::println);
				}
				static class User{
					private String name;
					private int age;
					public User(String name, int age) {
						super();
						this.name = name;
						this.age = age;
					}
					public String getName() {
						return name;
					}
					public void setName(String name) {
						this.name = name;
					}
					public int getAge() {
						return age;
					}
					public void setAge(int age) {
						this.age = age;
					}
					@Override
					public String toString() {
						return "User [name=" + name + ", age=" + age + "]";
					}
	}
}
