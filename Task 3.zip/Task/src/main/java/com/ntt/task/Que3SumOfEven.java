package com.ntt.task;

public class Que3SumOfEven {
	public static void main(String[] args) {
		int arr[] = { 2, 4, 89, 56, 77 };

		int sum = 0;
		for (int element : arr) {
			if ((element % 2) == 0) {
				System.out.println("even:" + element);
				sum = element + sum;
			}
		}
		System.out.println("sum of even num: " + sum);
	}
}
