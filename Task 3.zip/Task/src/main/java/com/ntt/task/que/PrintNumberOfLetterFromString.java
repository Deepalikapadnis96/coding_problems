package com.ntt.task.que;

import java.util.HashMap;
import java.util.Map;

public class PrintNumberOfLetterFromString {
	public static void main(String[] args) {
		// counting the number of letters from the word/string
		String letter = "DEEPALI";
		//char=for lettr , int for num of count
		Map<Character, Integer> countWorrds =new HashMap<Character, Integer>();
		for(char c : letter.toCharArray()) {
			System.out.println("char : " +  c);
			Integer merge = countWorrds.merge(c, 1, Integer::sum);
			System.out.println(" merge " + merge);
		}
						
		System.out.println("-->counting letter:" + countWorrds);		
				
				
}
	
}