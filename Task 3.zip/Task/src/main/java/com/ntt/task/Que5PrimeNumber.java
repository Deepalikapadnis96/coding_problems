package com.ntt.task;

public class Que5PrimeNumber {
	public static void main(String[] args) {
		// int array[] = { 22, 23, 7, 12, 9 };
		int num = 9;
		int temp = 0;
		for (int i = 2; i <= (num / 2); i++) {
			if ((num % i) == 0) {
				temp = temp + 1;
				System.out.println("data: " + temp);
			}
		}
		System.out.println("loop:" + (num - 1));
		if (temp > 0) {
			System.out.println("not prime:");
		} else {
			System.out.println("prime");
		}
	}
	}

