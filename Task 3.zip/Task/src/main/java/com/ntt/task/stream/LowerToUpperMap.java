package com.ntt.task.stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class LowerToUpperMap {
public static void main(String [] args) {
	System.out.println("stream apply + func is:");
	List<String> list = Arrays.asList("deepali", "deep", "dee", "d");
	List<String> list1 = list.stream()
			.map(String::toUpperCase)
			.collect(Collectors.toList());
	System.out.println(list1);
	
}
}
