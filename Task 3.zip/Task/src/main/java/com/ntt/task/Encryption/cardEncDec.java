package com.ntt.task.Encryption;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class cardEncDec {
	/**
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		// 4799470122357215 Visa --- z2uZCY6B8jhTukHIlaskhHNV3SJZgqa6mk2ERRSACA8=
		// 4012888888881881 VISA --- EoyYolGXUTWT3vxxca5UAHNV3SJZgqa6mk2ERRSACA8=
		// 5419190401747137 Master --- 9gxhyRsjjHhmgXOrNg3JtnNV3SJZgqa6mk2ERRSACA8=
		// 3569990010030442 JCB CC --- m+aCHS/ynZF3Xpyo0s0D+HNV3SJZgqa6mk2ERRSACA8=
		// 378282246310005 AMEX --- xs1gerh+krGRWvhSHXA8z6Xfsa/jJ7Df55U8wyddEgA=
		// 5555555555554444 --- UruGW0U1Id/dYWW6z6kW6HNV3SJZgqa6mk2ERRSACA8=
		// 6080320010424523
		String encrypt = cardEncDec.encryptData("4012888888881881|123|2023|12");
		System.out.println("encrypt : " + encrypt);

	}

	public static String encryptData(String sData) throws Exception {

		byte[] bPrivateKey = "61220121".getBytes();
		SecretKeySpec spec = new SecretKeySpec(bPrivateKey, "DES");
		Cipher cipher = Cipher.getInstance("DES");
		cipher.init(1, spec);
		byte[] bEncryptedData = cipher.doFinal(sData.getBytes());
		return Base64.getEncoder().encodeToString(bEncryptedData);
	}

	public static String decryptData(String sData) throws Exception {

		byte[] bPrivateKey = "61220121".getBytes();
		SecretKeySpec spec = new SecretKeySpec(bPrivateKey, "DES");
		Cipher cipher = Cipher.getInstance("DES");
		cipher.init(2, spec);
		byte[] bencryptedData = Base64.getDecoder().decode(sData);
		byte[] bDecryptedData = cipher.doFinal(bencryptedData);
		return new String(bDecryptedData);
	}

}
