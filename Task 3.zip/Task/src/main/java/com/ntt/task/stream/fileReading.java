package com.ntt.task.stream;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class fileReading {

	public static void main(String args[]) {
		Path path = Paths.get("E:\\Files\\" + "27062022_Validate_dbQuery.txt");
		File file = path.toFile();
//C:\\Users\\DeepaliKapadnis\\.m2\\repository\\org\\apache\\tomcat\\catalina\\6.0.53\\"
		{
			try {

				Scanner sc = new Scanner(file);
				while (sc.hasNextLine()) {
					System.out.println(sc.nextLine());
				}
				sc.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
