package com.ntt.task;

import java.util.ArrayList;

//The Java String class equals() method compares the two given strings based on
//the content of the string. If any character is not matched, it returns false.
//If all characters are matched, it returns true.
public class StringEquals {
	public static void main(String[] args)
{
		String s1 = "deepali";
		String s2 = "suraj";
		String s3 = "pooja";
		String s4 = "deepali";
		System.out.println(s1.equals(s4));
		System.out.println(s2.equals(s3));
		if (s1.equals(s4)) {
			System.out.println("data is same");
		} else {
			System.out.println("data is not same");
		}

		String str = "deepali";

		ArrayList<String> list = new ArrayList<String>();
		list.add("monal");
		list.add("pooja");
		list.add("deepali");
		for (String str1 : list) {
			if (str1.equals(str)) {
				System.out.println("deepali is present is array list");

		}
		}
	}
}
