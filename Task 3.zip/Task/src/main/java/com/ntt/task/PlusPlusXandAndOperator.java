package com.ntt.task;

//what will be the ouput of x and y also what will output if x++ and y++ ?
public class PlusPlusXandAndOperator {
static int x= 10;
static int y =15;
 public static void main(String[] args) {

	 if((++x < 10) && (++y >15)) {
		 x++;
	 }else {
		 y++;
	 }
	 System.out.println("x: " + x +"  y: "+ y);
 }

}
