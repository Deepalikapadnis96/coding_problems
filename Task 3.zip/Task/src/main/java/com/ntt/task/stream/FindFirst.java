package com.ntt.task.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class FindFirst {
public static void main(String[] args)
{
	List<String> list =  Arrays.asList("d","l","k", "l");
	/* Optional<String> list2 = Optional.empty(); */

	Optional<String> list1 = list.stream().findFirst();
	
	
	if (list1.isPresent()) {
		System.out.println(list1.get());
		
	}
	
	else {
		System.out.println("no value");
	}
}
}
