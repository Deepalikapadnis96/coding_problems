package com.ntt.task;

public class StringMethodsAndifStatement {
	public static void main(String[] arge) {
		int age = 20;
		String s5 = "DEEPALI KAPADNIS";

		String data = s5.replaceAll("[DP]", " ");
		System.out.println("daataa: " + data);
		String string = " deepali ";
		System.out.println(string.toUpperCase());
		System.out.println(string.toLowerCase());
		System.out.println(string.trim()); // remove the space before and after
		System.out.println(string.startsWith(" d"));
		System.out.println(string.endsWith("i "));
		System.out.println(string.charAt(1));// specific index position ---cz of space its taking d as 1
		System.out.println(string.charAt(4));
		System.out.println(String.join("-", "deepali", "kapadnis"));// join
		System.out.println(string.length());// length of word
		System.out.println(string.lastIndexOf("a"));
		System.out.println("upper case:: " + string.toUpperCase());
		System.out.println("lower case:: " + s5.toLowerCase());// to make upper case to lower case
		System.out.println(string.intern());// When the intern method is invoked, if the pool already contains a String
											// equal to this String object as determined by the equals(Object) method,
		System.out.println();

		// valueOf() method coverts given type such as int, long, float, double,
		// boolean, char and char array into String.
		String value = String.valueOf(age);
		System.out.println(value + age);

		// The String class replace() method replaces all occurrence of first sequence
		// of character with second sequence of character.
		String sentence = "The String class replace() method replaces all occurrence of first sequence of character with second sequence of character";
		String replaceString = sentence.replace("character", "word");
		System.out.println("replaceString : " + replaceString);

		// If first string is an empty string, the method returns a negative
		// If second string is an empty string, the method returns a positive number
		// that is the length of the first string.

		String s1 = "deep";
		String s2 = "";
		String s3 = "me";
		System.out.println("compare: " + s1.compareTo(s2));
		System.out.println("compare to: " + s2.compareTo(s3));
		// ---------------------------------------------------
		if ((age % 2) == 1) {
			System.out.println("age is greater than given num");
		} else {
			System.out.println("age is smaller than given num");
		}
	}
}
