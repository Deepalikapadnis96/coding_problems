package com.ntt.task;

//The Java String class contains() method searches the sequence of characters in this string.
//It returns true if the sequence of char values is found in this string otherwise returns false.
//The contains() method searches case-sensitive char sequence.
public class StringContains {
	public static void main(String[] args) {
		String data = "ntt data payment services near metro station ,chakala.";
		System.out.println(data.contains("near metro"));
		System.out.println(data.contains("nothing"));

		if (data.contains("ntt data")) {
			System.out.println("data is present");
		}
	}
}
