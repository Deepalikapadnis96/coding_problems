package com.ntt.task.que;

public class CountLetterFromString {
public static void main(String[] args) {
	
	String str = "deeeepali";
	char ch = 'e' ;
	int count =0;
	for(int i =0; i< str.length(); i++) {
		if(str.charAt(i)==ch) {
			count++;
			System.out.println( " count:" + count);

		}
	}
}
}
