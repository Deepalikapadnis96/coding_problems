package com.ntt.task;

public class Que6PrimeNumInArray {
	public static void main(String[] args) {
		int num = 0;
		int array[] = { 22, 39, 11, 7, 8, 29 };
		for (int i = 0; i < array.length; i++) {
			boolean isPrime = true;
			num = array[i];

			for(int j=2;j<=(num/2);j++) {
				if ((num % j) == 0) {
					isPrime = false;
					break;
				}
			}
			if (isPrime) {
				System.out.println("prime");

			} else {
				System.out.println("not prime");
		}
}
}
}