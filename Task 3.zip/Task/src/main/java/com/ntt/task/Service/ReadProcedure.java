package com.ntt.task.Service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadProcedure {

	public static void main(String[] args) throws Exception {
		File file = new File("E:\\Files\\procedure_Input_Files"); // folder path
		File[] listFiles = file.listFiles(); // return lists of files from the folder
		System.out.println("Files are: ");

		for (int i = 0; i < listFiles.length; i++) {
			File singleFile = listFiles[i];
			if (singleFile.isFile()) {// //this line weeds out other directories/folders
				System.out.println("\nget the file name : " + listFiles[i].getName());
				ReadProcedure.readProcedureData(singleFile);
			}
		}
	}

	public static void readProcedureData(File file) throws IOException {
		// File file = new File(listFiles);

		String name = file.getName();
		boolean canExecute = file.canExecute();
		boolean exists = file.exists();
		File absoluteFile = file.getAbsoluteFile();
		String absolutePath = file.getAbsolutePath();

		System.out.println("file name: " + name + " canExecute:" + canExecute + " exists:" + exists + " absoluteFile:"
				+ absoluteFile + " absolutePath:" + absolutePath + '\n');
		FileReader reader = new FileReader(file);

		boolean ready = reader.ready();
		System.out.println("ready : " + ready);

		FileWriter writer = new FileWriter("E:\\Files\\procedure_Output_Files\\" + file.getName());
		writer.write("parameter , DataType ");
		BufferedReader bufferReader = new BufferedReader(reader);
		String string;
		while ((string = bufferReader.readLine()) != null) {
			if (string.contains("IN ")) {// && (st.contains(" IN "))) {
				string = string.substring(string.indexOf("IN"), string.lastIndexOf(","));
				System.out.println("st: " + string);
				String[] splitByParam = string.split(" ");
				if (splitByParam[2].contains("),")) {
					String replace = splitByParam[2].replace("),", ")");
					String data = splitByParam[1] + "," + replace;

						System.out.println("if write: " + data);
						dataWrite(writer, data);

				} else {
					String data = splitByParam[1] + "," + splitByParam[2];

						dataWrite(writer, data);
						System.out.println("else write: " + data);
				}
			}
		}
			writer.close();
		}


	public static void dataWrite(FileWriter writer, String data) throws IOException {
		try {
			writer.write(System.getProperty("line.separator"));
			writer.write(data);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
