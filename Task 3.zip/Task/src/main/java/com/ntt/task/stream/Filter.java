package com.ntt.task.stream;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

public class Filter {
	public static void main(String[] args) {
		Stream<String> stream = Stream.of("Deepali", "POOJA", "Nilima");

		stream.filter(str -> Character.isUpperCase(str.charAt(1)))
				/* stream.filter(str -> str.endsWith("a")) */
				.forEach(System.out::println);
	}
}
