package com.ntt.task;

import java.util.ArrayList;

//The Java String class equalsIgnoreCase() method compares the two given strings on the
//basis of the content of the string irrespective of the case (lower and upper) of the string. It is just like the equals() method
//but doesn't check the case sensitivity.If any character is not matched, it returns false, else returns true
public class StringEqualIgnoreCase {
	public static void main(String[] args) {
		String s1 = "deepali";
		String s2 = "deepali";
		String s3 = "DEEPALI";
		String s4 = "pooja";
		System.out.println(s1.equalsIgnoreCase(s2));
		System.out.println(s2.equalsIgnoreCase(s3));
		System.out.println(s2.equalsIgnoreCase(s4));

		ArrayList<String> list = new ArrayList<String>();
		list.add("rina");
		list.add("mina");
		list.add("DeePaLi");
		list.add("dd");
		for (String str : list) {
			if (str.equalsIgnoreCase(s3)) {
				System.out.println("present in array List");
			} else {
				System.out.println("not in array list");
			}
		}
	}
}
