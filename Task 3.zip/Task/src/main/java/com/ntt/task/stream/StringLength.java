package com.ntt.task.stream;

import java.util.Arrays;
import java.util.List;

public class StringLength {
public static void main(String[] args) {
	System.out.println("stram  + funct");
	List<String> list = Arrays.asList("deepali","pooja", "nilima");
	list.stream().map(str -> str.length())
	.forEach(System.out::println);
	
}
}
