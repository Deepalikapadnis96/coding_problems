package com.ntt.task.stream;

public class ifElse {
	public static void main(String[] agrs) {
int x = 9;
if(x == 9) {
	System.out.println(true);
}else {
	System.out.println(false);
}
}
}
