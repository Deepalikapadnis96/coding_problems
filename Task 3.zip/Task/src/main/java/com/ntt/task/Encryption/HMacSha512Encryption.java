package com.ntt.task.Encryption;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.util.Formatter;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * @author RPP Team
 *
 */

public class HMacSha512Encryption {
	private static final String HMAC_SHA512_ALGORITHM = "HmacSHA512";

	private SecretKeySpec secretKeySpec;

	public String encrypt(String toBeEncryptString) throws Exception {
		if (toBeEncryptString == null) {
			throw new Exception("To be encrypt string must not be null");
		}

		try {
			Mac mac = Mac.getInstance(HMAC_SHA512_ALGORITHM);
			mac.init(secretKeySpec);
			return byteArray2Hex(mac.doFinal(toBeEncryptString.getBytes(UTF_8)));
		} catch (Exception ex) {
			throw new Exception("Error in encrypting the values using HMACSHA512 encryption", ex);
		}
	}

	public void setKey(String key) throws Exception {
		if (key == null) {
			throw new Exception("Key must not be null");
		}

		try {
			this.secretKeySpec = new SecretKeySpec(key.getBytes(UTF_8), HMAC_SHA512_ALGORITHM);
		} catch (Exception ex) {
			throw new Exception("Key could not be set", ex);
		}
	}

	public static String byteArray2Hex(byte[] bytes) {
		try (Formatter formatter = new Formatter()) {
			byte[] arrayOfByte = bytes;
			int j = bytes.length;
			for (int i = 0; i < j; i++) {
				byte b = arrayOfByte[i];

				formatter.format("%02x", Byte.valueOf(b));
			}
			return formatter.toString();
		}
	}

	public static void main(String args[]) {
		try {
			HMacSha512Encryption enc = new HMacSha512Encryption();
			enc.setKey("samplekey");
			System.out.println(enc.encrypt("sample value to generate signature"));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
