package com.ntt.task;

public class StringIsEmpty {

	public static void main(String[] args) {
		String s1 = "";
		String s0 = null;
		String s2 = "deepali";
		String s3 = "  ";

		System.out.println(s1.isEmpty());
		System.out.println(s2.isEmpty());
		System.out.println(s3.isEmpty());
		if (s0 == null) {
			System.out.println("s0 is null");
		}
	}
}
