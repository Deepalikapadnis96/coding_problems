package com.ntt.task.stream;

import java.lang.String;
import java.util.*;
import java.util.stream.IntStream;

public class IntegerStream {
	public static void main(String[] args) {

		IntStream stream = IntStream.range(1, 10)
				.skip(3); 
		stream.forEach(System.out::println);

		System.out.println("SUM");
		System.out.println(IntStream
				.range(1, 5)
				.sum());
		System.out.println();
	}

}
