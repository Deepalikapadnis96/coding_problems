package com.ntt.task;

public class StringIndexOf {
	public static void main(String[] args) {
		String sentence = "Ntt dta payment services, jb nagar";
		int count = 0;
		int startFrom = 0;
		for (;;) {
			int index = sentence.indexOf('a', startFrom);
			if (index >= 0) {
				count = count + 1;
				startFrom = index + 1;
			} else {
			break;
		}
		}
		System.out.println("string:" + sentence);
		System.out.println("count of a: " + count);
	}
}
