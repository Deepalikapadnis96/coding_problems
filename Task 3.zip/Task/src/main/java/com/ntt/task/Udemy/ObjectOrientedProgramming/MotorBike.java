package com.ntt.task.Udemy.ObjectOrientedProgramming;

public class MotorBike {
	int speed; // instance variable
	public static void main(String[] args) {
		MotorBike honda = new MotorBike();
		MotorBike ducati = new MotorBike();
		honda.start();
		ducati.start();
		// state
		honda.speed = 30;
		ducati.speed = 70;

}
	void start() {
		System.out.println("bike started");
	}

	void book() {
		System.out.println("names of book");
	}
}
