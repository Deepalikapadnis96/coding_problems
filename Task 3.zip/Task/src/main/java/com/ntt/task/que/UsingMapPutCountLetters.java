package com.ntt.task.que;

import java.util.HashMap;

public class UsingMapPutCountLetters {
	public static void main(String[] args) {
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();

		String data = "DEEPAlI";
		char[] charArray = data.toCharArray();
		for (int i = 0; i < charArray.length; i++) {
			if (!map.containsKey(charArray[i])) {
				map.put(charArray[i], 1);
			}
			map.put(charArray[i], map.get(charArray[i]) + 1);
		}
		System.out.println("-->>" + map.toString());
	}
}
