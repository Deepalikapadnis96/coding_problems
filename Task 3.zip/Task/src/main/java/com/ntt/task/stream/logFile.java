package com.ntt.task.stream;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class logFile {
	public static void main(String args[]) {
		try {
			FileInputStream file1 = new FileInputStream("E:\\Files\\" + "catalina.2022-07-06.log");
			BufferedReader br = new BufferedReader(new InputStreamReader(file1));
			String strLine;
			// int i = 1;
			while ((strLine = br.readLine()) != null) {
				System.out.println("==========================");
				System.out.println("line: " + strLine);
				String oneLine[] = strLine.split(" ");
				// String spacesAsPluses = oneLine[].replaceAll("\\s", "+");

				// System.out.println(oneLine);
				for (int j = 0; j < oneLine.length; j++) {
//					System.out.println("split data " + oneLine[j]);
//					 System.out.println(Pattern.matches("^(?=.*[A-Z])(?=.*[0-9])[A-Z0-9]+$" , oneLine[j]));
					 String expression = "(^[a-zA-Z]+[0-9])|(^[0-9]+[a-zA-Z])|(^[0-9]+)";
	                    Pattern pattern = Pattern.compile(expression);
	                    boolean isPatternMatches = pattern.matcher(oneLine[j]).find();
					if (isPatternMatches) {

						if ((oneLine[j].length() <= 19 && oneLine[j].length() >= 11)
								&& (!oneLine[j].contains("-") && !oneLine[j].contains("_") && !oneLine[j].contains(".")
                                        && !oneLine[j].contains(":"))) {
							// || oneLine[j].contains("_")
							// System.out.println("length is greater than 11 and less than 19 " +
							// oneLine[j]);

							System.out.println("Pattern matches: " + oneLine[j].toString());
							boolean shouldValidate = isNumberStartWithAlphOrEndWithAlphaOrDoesNotContainsAlpha(oneLine[j]);
							boolean flag = false;
							if (shouldValidate)
								flag = isValidCardNumber(oneLine[j].replaceAll("[a-zA-Z]", ""));
							if (flag) {
								System.out.println("CARD NUMBER " + oneLine[j].toString() + " IS VALID ");

							} else {
								System.out.println("CARD NUMBER " + oneLine[j].toString() + " IS NOT VALID");
							}
						} /*
							 * else if (oneLine[j].length() < 10) {
							 * System.out.println("Length of number is smaller than required one  " +
							 * "CARD NUMBER IS FASLE: " + oneLine[j].toString()); }
							 */
					}
//					else {System.out.println("Pattern does not match");}
					// i++;
				}
			}
			file1.close();
		} catch (Exception e) {
			e.printStackTrace();
//			System.out.println("Error: " + e.getMessage());
		}

	}

	private static boolean isValidCardNumber(String cardNumber) {
		System.out.println("cardNumber " + cardNumber);
		int[] creditCardInt = new int[cardNumber.length()];
		for (int i = 0; i < cardNumber.length(); i++) {
			creditCardInt[i] = Integer.parseInt(cardNumber.substring(i, i + 1));
		}
		for (int i = creditCardInt.length - 2; i >= 0; i = i - 2) {
			int tempValue = creditCardInt[i];
			tempValue = tempValue * 2;
			if (tempValue > 9) {
				tempValue = tempValue % 10 + 1;

			}
			creditCardInt[i] = tempValue;
		}
		int total = 0;
		for (int i = 0; i < creditCardInt.length; i++) {
			total += creditCardInt[i];
		}
		// div by 10
		if (total % 10 == 0) {
			return true;
		} else {
			return false;

		}

	}
	private static boolean isNumberStartWithAlphOrEndWithAlphaOrDoesNotContainsAlpha(String cardNumber)
    {
	
        String expression = "(^[a-zA-Z])|(\\b\\d+\\b)";
        Pattern pattern = Pattern.compile(expression);
        boolean isPatternMatches = pattern.matcher(cardNumber).find();
        if (isPatternMatches)
            return true;

        String reverseCardNumber = new StringBuilder(cardNumber).reverse().toString();
        isPatternMatches = pattern.matcher(reverseCardNumber).find();
        if (isPatternMatches)
            return true;

        return false;
    }
}
