package com.microservice.limitservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.limitservice.beans.Limits;
import com.microservice.limitservice.configuration.Configuration;

@RestController
public class LimitsController {

	private Configuration configuration;

	public LimitsController(Configuration configuration) {
		super();
		this.configuration = configuration;
	}

	@GetMapping("/limits")
	public Limits retriveLimits() {
		return new Limits(configuration.getMinimum(), configuration.getMaximum());
		// return new Limits(1, 100);
	}
}
