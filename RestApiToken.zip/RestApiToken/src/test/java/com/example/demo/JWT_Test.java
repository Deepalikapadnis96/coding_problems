package com.example.demo;

import java.util.Base64;
import com.example.demo.util.JWTUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

public class JWT_Test {

	public static String secret_key="Aai@!1526";
	public static void main(String[] args) {
		String token = JWTUtil.generateToken("Token1", secret_key);
		System.out.println("----------TOKEN--------");
		System.out.println(token);
		System.out.println();
		System.out.println("------------CLAIMS------");
		Claims claims= Jwts.parser()
				.setSigningKey(Base64.getEncoder().encode(secret_key.getBytes()))
				.parseClaimsJws(token)
				.getBody();
				
		System.out.println("Token ID:  " + claims.getId());
		System.out.println("Token Subject:  " + claims.getSubject());
		System.out.println("Token Issuer:  " + claims.getIssuer());
		System.out.println("Token Issuer Date:  " + claims.getIssuedAt());
		System.out.println("Token Expiration Date:  " + claims.getExpiration());
		System.out.println("Token Audience:  " + claims.getAudience());

		
	}
}
