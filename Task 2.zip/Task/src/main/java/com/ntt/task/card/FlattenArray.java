package com.ntt.task.card;

import java.util.ArrayList;
import java.util.List;

public class FlattenArray {
	public static void main(String[] args) {
		Object[] nest1= {new Object[] {new Object[] {new Object[] {1},2},new Object[] {3,4,}},5};
		List<Number> list= flatten(nest1);
		System.out.println(list);
	}

	public static List<Number> flatten(Object[] nestedArray) {
		List<Number> list = new ArrayList<>();
		flattenHelper(nestedArray, list);
		return list;
	}

	public static void flattenHelper(Object[] nestedArray, List<Number> result) {
		for (Object element : nestedArray) {
			if (element instanceof Object[]) {
				flattenHelper((Object[]) element, result);
			} else if (element instanceof Number) {
				result.add((Number) element);
			}
		}
	}
}
