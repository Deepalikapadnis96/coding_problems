package com.ntt.task.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StringVowelCount {
	public static void main(String[] args) {
		String str = "Deepali Kapadnis";
		List<Character> asList = Arrays.asList('a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U');
		Map<Character, Long> collect = str.chars().mapToObj(x -> (char) x).filter(asList::contains)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(collect);
	}
}
