package com.ntt.task.array;

import java.util.Arrays;

public class SecondHighest {
public static void main(String[] args) {
	int[] arr = { 23,99,100,372,99,28,234};
	SecondHighest.data(arr);
	SecondHighest.data1(arr);
	//-----1----
	//Arrays.sort(arr);
	int i = arr[arr.length-2];
	System.out.println("by sorrting array>"+i);
	
	//-----2------
}
static void data1(int[] arr) {
	System.out.println("----------");
	int minValue = Integer.MIN_VALUE;
	int minValue2 = Integer.MIN_VALUE;
	for(int k=0;k<arr.length;k++) {
	if(arr[k]>minValue) {//23>min vl,99>23,100>99,372>100
		minValue2=minValue;//minval2=min val eg 0 , 23,99
		minValue=arr[k];//min val=23,99,100
		
	}else if (arr[k]>minValue2 && arr[k]!=minValue) {//minval2=100,234>100
		minValue2=arr[k];
		
	}
	}System.out.println("by min value>"+minValue2);

}

static void data(int[] arr) {
	System.out.println("------java8----");
	Arrays.stream(arr).sorted().skip(5).limit(1).forEach(System.out::println);
}

}
