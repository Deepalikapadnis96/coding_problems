package com.ntt.task;

public class CheckIfAlphabate {
public static void main(String[] args) {
	//char c = 'p';
	char[] str = {'a','e','i','o','u'};
	for(char a:str) {
	if((a>='a' && a<'z') || (a>='A' && a<='Z')){
		System.out.println("is alphabate");
	}else {
		System.out.println("is not alpabate");
	}
}
}
}