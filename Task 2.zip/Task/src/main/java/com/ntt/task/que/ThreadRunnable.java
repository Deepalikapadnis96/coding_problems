package com.ntt.task.que;

public class ThreadRunnable extends Thread {
	// Implementing runnable interface by extending Thread class
	// run() method to perform action for thread.

	public void run() {
		int x = 10;
		int y = 12;
		System.out.println(">>" + x + y);
	}

	public static void main(String[] args) {
		// Creating instance of the class extend Thread class
		ThreadRunnable thr = new ThreadRunnable();
		// Creating instance of the class extend Thread class
		thr.start();
	}
}
