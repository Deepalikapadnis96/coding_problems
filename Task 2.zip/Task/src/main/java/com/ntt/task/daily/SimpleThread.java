package com.ntt.task.daily;

import java.util.concurrent.atomic.AtomicInteger;
//The join() method of thread class waits for a thread to die. It is used when you want one thread to wait for
//completion of another. This process is like a relay race where the second runner waits until 
//the first runner comes and hand over the flag to him.

public class SimpleThread {
	public static void main(String[] args) throws InterruptedException {
		System.out.println("start--->");
		process pt = new process();
		Thread t1 = new Thread(pt, "t1");
		Thread t2 = new Thread(pt, "t2");
		System.out.println(t2);
		t2.start();
		//t1.join();
		 //t2.join();
		System.out.println("Processing count=" + " " + t1 + "" + t2 +" "+ pt.getCount());
	}
}

class process implements Runnable {
	AtomicInteger count = new AtomicInteger();

	@Override
	public void run() {
		for (int i = 0; i < 9; i++) {

			processSomething(i);
			count.incrementAndGet();
		}
	}

	public AtomicInteger getCount() {
		return this.count;
	}

	private void processSomething(int i) {
		// processing some job
		try {
			Thread.sleep(i * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
