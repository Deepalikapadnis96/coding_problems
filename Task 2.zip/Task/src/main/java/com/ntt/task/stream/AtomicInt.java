package com.ntt.task.stream;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class AtomicInt {
	public static void main(String[] args) {

		// 1. to modify primitive is easy using arthmetic operator
		int p = 10;
		p++;
		System.out.println(p);

		// 2. modify wrapper class is difficult it will give the error like.
		// "Local variable num defined in an enclosing scope must be final or
		// effectively final"
		Integer num = 10;
		num = num + 1;
		List<Integer> asList = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
		// asList.stream().map(x -> x *
		// num).collect(Collectors.toList()).forEach(System.out::println);

		// 3. To solve the issue java 8 realease the atomic integer in pkg or
		// java.util.concurrent.integer pkg

		AtomicInteger atomicInt = new AtomicInteger(11);
		int andIncrement = atomicInt.getAndIncrement();
		int andIncrement1 = atomicInt.getAndIncrement();
		int andAdd = atomicInt.getAndAdd(2);
		int addAndGet = atomicInt.addAndGet(3);//(13+2=15  15+3=18)
		int incrementAndGet = atomicInt.incrementAndGet();
		System.out.println("atomic intger>>" + andIncrement + " andIncrement1 " + andIncrement1 + " get and add > "
				+ andAdd + " add and get >>" + addAndGet + " incrementAndGet >>" + incrementAndGet);

	}
}
