package com.ntt.task.que;

public class Parent11 {

	public static void main(String[] args) {
		Master p = new Salve();
		p.run();
	}
}

class Master {
	void run() {
		walk();
		System.out.println("in run method");
	}

	void walk() {
		System.out.println("in walk method");
	}
}

class Salve extends Master {
	void run() {
		super.run();
		System.out.println("in child run method");
	}
	@Override
	void walk() {
		System.out.println("in child walk method");
	}
}
