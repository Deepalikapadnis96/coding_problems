package com.ntt.task.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ElevenMethod {
public static void main(String[] args) {
	 boolean blank = "deepali".isBlank();
	 String repeat = "deep".repeat(3);
	 Stream<String> lines = "dee".lines();
	 lines.forEach(x->System.out.println(x));
	 
	 String strip = " hri ".strip();//remove white spcae
	 String stripTrailing = " hrith ".stripTrailing();
	 String stripLeading = " hrithik ".stripLeading();
	 
	 
	 System.out.println("---------------------");
	 
	 String testString = "hello\nworld\nis\nexecuted";

	    List<String> liness = new ArrayList<>();

	  testString.lines().forEach(liness::add);
	 System.out.println("line>>"+testString);
	 System.out.println("blank>>"+blank);
	 System.out.println("repeat>>"+repeat);
	 System.out.println("strip>>"+strip+" start");
	 System.out.println("start"+stripTrailing+"end");
	 System.out.println("start"+stripLeading+"end");
	 
	 System.out.println("------------------------");
	 List<String> names = new ArrayList<>();
	    names.add("alex");
	    names.add("brian");
	    names.add("charles");

	    String[] namesArr1 = names.toArray(new String[names.size()]);		//Before Java 11

	    String[] namesArr2 = names.toArray(String[]::new);    //after java 11
	    System.out.println("arr1>>"+ Arrays.toString(namesArr1) +" arr2>>" + Arrays.toString(namesArr2));

}	
}
