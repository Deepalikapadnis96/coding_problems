package com.ntt.task.singletondesignpattern;

/**
 * @author DeepaliKapadnis 
 * singleton design pattern :create object onces and
 *         use through out the project so basic logic is that we need to prevent
 *         creation of multiple object 1) create private const not public
 *         becouse using public const we need to create mutiple object 2) object
 *         create with the help of method (getschool) 3) create field to store
 *         private variable
 */
public class OneObject {

	private static OneObject oneObject;

	private OneObject() { //make constructor private
		if(oneObject !=null) {
			throw new RuntimeException("you are try to break singlton design pattern");
		}
	}

	public static OneObject getObject() {
    	oneObject = new OneObject();

		if (oneObject == null) {
			oneObject = new OneObject();
		}
		return oneObject;
	}
	//eger way of creating singleton object
	 	
	    public static OneObject getegerSchool() {
	    	OneObject oneObject = new OneObject();
			return oneObject;
	 }
	    
	public static void main(String[] args) {

		OneObject s1 = OneObject.getObject();
		System.out.println(s1.hashCode());

		OneObject s111 = OneObject.getegerSchool();
		System.out.println(">1>>"+s111.hashCode());
		
		OneObject s112 = OneObject.getegerSchool();
		System.out.println(">2>>"+s112.hashCode());
		
		OneObject s2 = OneObject.getObject();
		System.out.println(">>" + s2.hashCode());

	}
}
