package com.ntt.task.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class reverseOrder {
	public static void main(String[] args) {
		List<String> of = List.of("deep", "avni", "monal");
		List<String> collect = of.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println("first>> " + collect);

		List<String> asList = Arrays.asList("Deepali", "Monal", "Bhavana", "vishakha");
		List<String> collect2 = asList.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println("des order >> " + collect2 + " " + asList);

		List<String> asList2 = Arrays.asList("deepali", "lina", "avni");
		List<String> collect3 = asList2.stream().sorted().collect(Collectors.toList());
		List<String> collect33 = asList2.stream().sorted((x, y) -> y.compareTo(x)).collect(Collectors.toList());
		System.out.println("asc order>> " + collect3);
		System.out.println("desc order>> " + collect33);

	}
}