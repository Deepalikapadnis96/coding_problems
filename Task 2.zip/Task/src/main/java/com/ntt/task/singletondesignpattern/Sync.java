package com.ntt.task.singletondesignpattern;


public class Sync {
	private static Sync sync;

	public synchronized static Sync getSync() {
		if (sync == null) {
			sync = new Sync();
		}
		return sync;
	}
	
	public static Sync getSyncc() {  
		if(sync == null) {	
			synchronized (Sync.class) {
				if(sync ==null) {
				sync = new Sync();
				}
			}		
		}
		return sync;
	}
	
	public static void main(String[] args) {
		Sync sync = new Sync().getSync();
		System.out.println(">>"+sync);
		
	}
}
