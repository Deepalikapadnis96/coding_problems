package com.ntt.task.stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Collect {
//.collect(Collectors.toList())
//.collect(Collectors.toCollection(TreeSet::new));
// .collect(Collectors.joining(", "));
// .collect(Collectors.summingInt(Employee::getSalary)));
//.collect(Collectors.groupingBy(Employee::getDepartment, Collectors.summingInt(Employee::getSalary)));
	
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		for(int i=1;i<10;i++) {
			list.add(i);
		}
		//list.stream().filter(i -> i%2 == 0).collect(Collectors.toList()).forEach(System.out::println);
		Integer[] array = list.stream().filter(i -> i%2 ==0).toArray(Integer[]::new);
		System.out.println(">>"+ Arrays.toString(array));
	}
}
