package com.ntt.task.collections;

import java.util.LinkedHashMap;
import java.util.Map;

public class HashmapIncrValueBy1 {
public static void main(String[] args) {
	LinkedHashMap<String, Integer> map = new LinkedHashMap<>();
	map.put("deepali", 1);
	map.put("monal", 2);
	map.put("neha", 3);
	for(Map.Entry<String, Integer> entry: map.entrySet()) {
		
		String key = entry.getKey();
		Integer value = entry.getValue();
		//value = value+1;
		Integer merge = map.merge(key, value, Integer::sum);
		System.out.println("key "+ key +" value "+value + " merge "+merge);
	}
}
}
