package com.ntt.task.stream;

public class ReverseStringWithRecursion {
public static void main(String[] args) {
	ReverseStringWithRecursion reverseStringWithRecursion = new ReverseStringWithRecursion();
	String reverseString = reverseStringWithRecursion.reverseString("deepali");
	System.out.println(">>>" +reverseString);
	
}
public  String reverseString (String str) {
	if(str.isEmpty()) {
		System.out.println("String is empty");
		return str;
	}else {
	String re=reverseString(str.substring(1))+str.charAt(0);
	System.out.println("substring:: " + str.substring(1) + " | " + str.charAt(0) );
	//System.out.println("data:: " + re);
	return re;
	}
	
}
}
