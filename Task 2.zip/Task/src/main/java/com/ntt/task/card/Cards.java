package com.ntt.task.card;

public class Cards {
	private Suits suits;
	private Rank rank;

	public Cards(Suits suits, Rank rank) {
		super();
		this.suits = suits;
		this.rank = rank;
	}

	@Override
	public String toString() {
		return "Cards [suits=" + suits + ", rank=" + rank + "]";
	}

	public Suits getSuits() {
		return suits;
	}

	public void setSuits(Suits suits) {
		this.suits = suits;
	}

	public Rank getRank() {
		return rank;
	}

	public void setRank(Rank rank) {
		this.rank = rank;
	}

}
