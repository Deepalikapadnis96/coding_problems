package com.ntt.task.que;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class CardClass {
	public static void main(String[] args) {
		CardClass cardClass= new CardClass();
		DeckOfCard deck = cardClass.new DeckOfCard();
		System.out.println(sortCards(deck.list).toString());
		Card card1 = deck.list.get(2);
		Card card2 = deck.list.get(10);
		System.out.println(" "+card1 + " " + card2 +" " );
		//System.out.println(" " + (card1,card2));
	}

	public static ArrayList<Card> sortCards(ArrayList<Card> cards) {
		cards.sort(Comparator.comparing(Card::getSuit).thenComparing(Card::compareTo));
		return cards;

	}

	public static Card bigCard(Card first, Card second) {
		return first.compareTo(second) >= 0 ? first : second;
	}

	public class Card implements Comparable<Card> {
		private Suit suit;
		private Rank rank;

		public Suit getSuit() {
			return suit;
		}

		public Rank getRank() {
			return rank;
		}

		public Card(Suit suit, Rank rank) {
			super();
			this.suit = suit;
			this.rank = rank;
		}

		@Override
		public String toString() {
			return "Card [suit=" + suit + ", rank=" + rank + "]";
		}

		@Override
		public int compareTo(Card o) {
			int compareTo = this.rank.compareTo(o.rank);
			if (compareTo != 0) {
				return compareTo;
			}
			return this.suit.compareTo(o.suit);
		}

	}

	enum Suit {
		HEART, DIAMON, SPADE, CUBES;
	}

	enum Rank {
		ACE, KING, QUEEN, JACK, TEN, NINE, EIGHT, SEVEN, SIX, FIVE, FOUR, THREE, TWO;
	}

	class DeckOfCard {
		final ArrayList<Card> list;

		public DeckOfCard() {
			Suit[] suits = Suit.values();
			Rank[] rank = Rank.values();
			list = new ArrayList<>();
			for (int i = 0; i < suits.length; i++) {
				for (int j = 0; j < rank.length; j++) {
					this.list.add(new Card(suits[i], rank[j]));
				}
			}
			Collections.shuffle(this.list);
		}
	}
}
