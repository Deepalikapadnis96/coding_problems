package com.ntt.task.designpattern;

public class Demo {

	public static void main(String[] args) {

         Subscriber harshit  = new Subscriber();
         HrithikSub hrithik  = new HrithikSub();
         DeepaliChannal deepaliChannal = new DeepaliChannal();
         deepaliChannal.subscriberadd(harshit);
         deepaliChannal.subscriberadd(hrithik);
         deepaliChannal.notified();

	}

}
