package com.ntt.task.questions;

import java.util.Scanner;

public class que {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter:");
		int nextInt2 = sc.nextInt();
		
		int N =0;
		int sum =0;
		int[] data = new int[N];
		for(int i=0; i<data.length;i++) {
			int nextInt = sc.nextInt(data[i]);
			int d=nextInt%10;
			sum+= d;
			System.out.println(sum);
		}
	}
}