package com.ntt.task.stream;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class FindDuplicateElementInIntList {
	public static void main(String[] args) {
		// use !set for duplicate integers and use set:: add for unique element

		List<Integer> asList = Arrays.asList(10, 2, 32, 12, 12, 34, 54, 65, 44, 44, 66, 2, 8, 1, 0, 1);
		Set<Integer> set = new HashSet<>();
		// asList.stream().filter(set::add).collect(Collectors.toSet()).forEach(System.out::println);
		System.out.println("------------");
		asList.stream().filter(x -> !set.add(x)).collect(Collectors.toSet()).forEach(System.out::println);
	
	}
}
