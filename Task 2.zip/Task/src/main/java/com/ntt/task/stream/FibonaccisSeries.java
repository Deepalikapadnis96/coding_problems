package com.ntt.task.stream;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FibonaccisSeries {
public static void main(String[] args) {

Stream.iterate(new int[] {0, 1},fib->new int[] {fib[1],fib[0]+fib[1]})//first 2 num 0,1 
//fib->new int[] {fib[1],fib[0]+fib[1]}---> this func takes previous 2 fibinaci num n generate next
.limit(7).map(fib->fib[0]).collect(Collectors.toList()).forEach(System.out::println);

}

}
