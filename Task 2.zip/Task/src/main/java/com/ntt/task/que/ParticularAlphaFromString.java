package com.ntt.task.que;

public class ParticularAlphaFromString {
	public static void main(String[] args) {
		String str = "deepali kapadnis";
		char letter = 'a';
		int countAlphabate = countAlphabate(str, letter);
		System.out.println("countAlphabate :" + countAlphabate);

	}

	public static int countAlphabate(String str, char letter) {
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			if (Character.toLowerCase(str.charAt(i)) == Character.toLowerCase(letter)) {
				count++;
			}
		}
		return count;

	}
}
