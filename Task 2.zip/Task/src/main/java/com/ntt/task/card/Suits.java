package com.ntt.task.card;

public enum Suits {
	CLUBS, DIAMONDS, HEARTS, SPADES;
}
