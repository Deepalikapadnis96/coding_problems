package com.ntt.task.thread;

public class ThreadExtend extends Thread {
	
	@Override
	public void run() {
		for(int i=0;i<10;i++) {
		System.out.println("in child class " +i);
		System.out.println("daemon thread> "+ Thread.currentThread().isDaemon());
		}
		//super.run();
	}
}
