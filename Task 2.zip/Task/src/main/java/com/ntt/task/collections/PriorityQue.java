package com.ntt.task.collections;

import java.util.PriorityQueue;

public class PriorityQue {
public static void main(String[] args) {
	PriorityQueue< String> p = new PriorityQueue<>();
	p.add("dog");
	p.add("cat");
	p.add("all");
	
	System.out.println(p);
}
}
