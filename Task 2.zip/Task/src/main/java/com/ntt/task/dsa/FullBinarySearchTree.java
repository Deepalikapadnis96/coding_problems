package com.ntt.task.dsa;

public class FullBinarySearchTree {
	int data;
	FullBinarySearchTree leftChild, rightChild;

	FullBinarySearchTree(int item) {
	  data = item;
	  leftChild = rightChild = null;
	  }
	}

	class BinaryTree {
		FullBinarySearchTree root;

	  // Check for Full Binary Tree
	  boolean isFullBinaryTree(FullBinarySearchTree node) {

	  // Checking tree emptiness
	  if (node == null)
	    return true;

	  // Checking the children
	  if (node.leftChild == null && node.rightChild == null)
	    return true;

	  if ((node.leftChild != null) && (node.rightChild != null))
	    return (isFullBinaryTree(node.leftChild) && isFullBinaryTree(node.rightChild));

	  return false;
	  }

	  public static void main(String args[]) {
	    BinaryTree tree = new BinaryTree();
	    tree.root = new FullBinarySearchTree(1);
	    tree.root.leftChild = new FullBinarySearchTree(2);
	    tree.root.rightChild = new FullBinarySearchTree(3);
	    tree.root.leftChild.leftChild = new FullBinarySearchTree(4);
	    tree.root.leftChild.rightChild = new FullBinarySearchTree(5);
	    tree.root.rightChild.leftChild = new FullBinarySearchTree(6);
	    tree.root.rightChild.rightChild = new FullBinarySearchTree(7);

	    if (tree.isFullBinaryTree(tree.root))
	      System.out.print("The tree is a full binary tree");
	    else
	      System.out.print("The tree is not a full binary tree");
	  }
	}
