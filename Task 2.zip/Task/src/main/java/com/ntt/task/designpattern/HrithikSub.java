package com.ntt.task.designpattern;

public class HrithikSub implements Observer{

	@Override
	public void getnotification() {
	System.out.println("Hi harshit you fav youtube deepali upload yoga video qhsjfkw");
		
	}
}
