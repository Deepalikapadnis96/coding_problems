package com.ntt.task.UdemyMain;

import java.math.BigDecimal;

import com.ntt.task.Udemy.ObjectOrientedProgramming.SimpleIntersetCalculation;

public class SimpleInterestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SimpleIntersetCalculation simpleIntersetCalculation = new SimpleIntersetCalculation("444.00", "34.00");
		BigDecimal totslValue = simpleIntersetCalculation.calculateTotalVale(5); // 5 years
		System.out.println(totslValue);
	}

}
