package com.ntt.task.que;

import java.util.HashSet;

public class TripletSumZero {
	public static void main(String[] args) {
		int[] array = { 1, 2, 4, -1, -2, -3 };
		HashSet<Integer> s = new HashSet<>();

		for (int i = 0; i <= array.length; i++) {

			for (int j = i + 1; j < array.length - 1; j++) {
				int sum = -(array[i] + array[j]);
				int k= array[j+1];
				if ( sum+ k==0) {
					System.out.println(array[i] + " " + array[j] + " " + k);
				}
				//System.out.println(array[i] + " " + array[j] + " " + sum);

				// int total =-sum;
				// int k=j+1;
				// System.out.println("total>>"+total + " k>>"+k);
				// if(-sum-k==0) {
				// for (int k = j+1; k < array.length; k++) {
				// System.out.println(" >>> " +sum+" "+k);
				// }

				// }

			}
		}
	}
}
