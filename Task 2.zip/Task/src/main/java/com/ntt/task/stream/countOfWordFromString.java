package com.ntt.task.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class countOfWordFromString {
	public static void main(String[] args) {
		String str = "deepali worked for nttdata as a for backend developer";
		Map<String, Long> collect2 = Arrays.stream(str.split("\\s"))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("str>> " + collect2);

		countOfWordFromString c = new countOfWordFromString();
		c.d("dddd ssss");
		c.d1("aamcndhhnfhbgvfgg");
		c.d2("deep avni");
		c.d3();
		c.d4();
		c.d5();
		c.d6(); c.d7();

	}

	void d(String s) {
		Map<String, Long> collect = Arrays.stream(s.split("\\s"))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("d >>" +collect);
	}

	void d1(String a) {
		Map<Character, Long> collect = a.chars().mapToObj(x -> (char) x)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("Each character d1 > " + collect);
	}

	void d2(String a) {
		String s = Arrays.stream(new StringBuilder(a).reverse().toString().split("\\s+"))
				.map(x -> new StringBuilder(x).reverse().toString()).collect(Collectors.joining(" "));
		System.out.println("reverse d2>>" + s);
	}

	void d3() {
		List<Integer> of = List.of(2, 3, 4, 5, 6, 7, 8, 9, 10, 11);
		List<Integer> collect = of.stream().filter(countOfWordFromString::isPrime).collect(Collectors.toList());
		System.out.println("is prime num d3>>" + collect);
	}

	static boolean isPrime(int n) {
		return n > 1 && IntStream.range(2, n).noneMatch(x -> n % x == 0);
	}

	void d4() {
		List<String> of = List.of("deepali");
		Map<Character, Long> collect2 = of.stream().flatMap(x -> x.chars().mapToObj(c -> (char) c))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		Map<String, Long> collect = of.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(">>" + collect2);
		collect.forEach((x, y) -> System.out.println(x + " : " + y));
	}

	void d5() {
		String str = "deepalikapadnis";
		Map<Character, Long> collect = str.chars().mapToObj(x -> (char) x)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("character count>>" + collect);
	}

	void d6() {
		List<String> asList = Arrays.asList("Deepalik");
		String string = asList.get(0);
		Map<Character, Long> map = string.chars().mapToObj(x -> (char) x)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("count the character using list>>" + map);
	}

	void d7() {
		System.out.println("======count of whole string=======");
		List<String> asList = Arrays.asList("Deepalik");
		long count = asList.stream().flatMapToInt(CharSequence::chars).count();
		System.out.println("count of String >>" + count);
	}
}
