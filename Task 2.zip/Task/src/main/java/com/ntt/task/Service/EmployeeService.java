package com.ntt.task.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.ntt.task.pojo.EmployeeDetails;

public class EmployeeService {
	public static void main(String[] args) {

		ArrayList<EmployeeDetails> employeeList = new ArrayList<EmployeeDetails>();
		EmployeeDetails empdetails = new EmployeeDetails();
		EmployeeDetails empdetails1 = new EmployeeDetails();
		EmployeeDetails empdetails2 = new EmployeeDetails();

		empdetails.setEmpName("deepali");
		empdetails.setEmpAge(26);
		empdetails.setEmpSalary(20000);

		empdetails1.setEmpName("Suraj");
		empdetails1.setEmpAge(25);
		empdetails1.setEmpSalary(20000);

		empdetails2.setEmpName("mayur");
		empdetails2.setEmpAge(30);
		empdetails2.setEmpSalary(20000);

		employeeList.add(empdetails);
		employeeList.add(empdetails1);
		employeeList.add(empdetails2);

		Collections.sort(employeeList);

		Iterator<EmployeeDetails> iterator = employeeList.iterator();
		while (iterator.hasNext()) {
			System.out.println(iterator.next());

		}
	}
}