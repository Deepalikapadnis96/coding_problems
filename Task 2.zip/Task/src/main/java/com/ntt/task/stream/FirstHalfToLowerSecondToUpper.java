package com.ntt.task.stream;

import java.util.stream.IntStream;

public class FirstHalfToLowerSecondToUpper {
	public static void main(String[] args) {
		String str = "Deepali Kapadnis";
		String convert = FirstHalfToLowerSecondToUpper.convert(str);
		System.out.println("String >>" + convert);
	}

	public static String convert(String input) {
		int length = input.length();
		int mid = length / 2;
		String firstHalf = IntStream.range(0, mid).mapToObj(i -> String.valueOf(input.charAt(i)).toLowerCase())
				.reduce("", String::concat);

		String secondHalf = IntStream.range(mid, length).mapToObj(i -> String.valueOf(input.charAt(i)).toUpperCase())
				.reduce("", String::concat);
		return firstHalf + secondHalf;
	}
}
