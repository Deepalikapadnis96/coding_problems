package com.ntt.task;

//what will be the ouput of x and y also what will output if x++ and y++ ?
public class PlusPlusXandAndOperator {
static int x= 10;
static int y =15;
 public static void main(String[] args) {
	 System.out.println(">" + ++x+ " >>" + x++) ;
	 if((++x < 10) && (++y >15)) {
		// x++;
		 y++;
		 
	 }else {
		 x++;
	 }
	// System.out.println(".." + ++x);

	 System.out.println("x: " + x +"  y: "+ y);
 }

}
