package com.ntt.task;

public class MultiplicationTable {
public static void main(String[] args) {
	multiple();
	multipleTable(4);
	tableFromTo(2, 4, 8);
}
	static // for particular 5 table
	void multiple() {

		for (int i = 1; i <= 10; i++) {
			System.out.printf("%d*%d=  %d ", 5, i, 5 * i).println();
		}
	}
	// for any table by mentioning in main method which table we want

	static void multipleTable(int table) {
		for (int i = 1; i <=10; i++) {
			System.out.printf("%d * %d =%d", table, i, table * i).println();
		}
	}

	// table "from" to "to"
	static void tableFromTo(int table, int from, int to) {
		for (int i = from; i <= to; i++) {
			System.out.printf("%d*%d=%d", table, i, table * i).println();
		}
	}
}
