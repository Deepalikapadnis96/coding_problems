package com.ntt.task.designpattern;

import java.util.ArrayList;
import java.util.List;

public class DeepaliChannal implements Observable{
	
	List<Observer> subscriberlist = new ArrayList<>();

	@Override
	public void subscriberadd(Observer obs) {
		subscriberlist.add(obs);
		
	}

	@Override
	public void unsubscribe(String obs) {
		subscriberlist.remove(obs);
	}

	@Override
	public void notified() {
		for(Observer ob : this.subscriberlist) {
			ob.getnotification();
		}
		
	}

}
