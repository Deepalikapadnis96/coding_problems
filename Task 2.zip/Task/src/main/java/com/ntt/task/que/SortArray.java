package com.ntt.task.que;

import java.util.ArrayList;
import java.util.List;

public class SortArray {
	public static void main(String[] args) {
		int[] a = {1,2,3};
		int[] b = {2,5,6};
		int[] merge = merge(a, b);
		for(int num:merge) {
		System.out.println("merge>>" + num);
	}
	}

	public static int[] merge(int[] a, int[] b) {
		int i = 0;
		int j = 0;
		List<Integer> list = new ArrayList<>();
		while (i < a.length && j < b.length) {

			if (a[i] <= b[j]) {
				list.add(a[i]);
				i++;

			} else {
				list.add(b[j]);
				j++;
			}
		}
		while (i < a.length) {
			list.add(a[i]);
			i++;
		}
		while (j < b.length) {
			list.add(b[j]);
			j++;
		}
		int[] size = new int[list.size()];
		for (int k = 0; k < list.size(); k++) {
			size[k] = list.get(k);
		}
		return size;
	}
}
