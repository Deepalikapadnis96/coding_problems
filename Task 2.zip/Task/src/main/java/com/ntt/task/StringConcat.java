package com.ntt.task;

public class StringConcat {
	public static void main(String[] args) {
		String data1 = "NTT data";
		String data2 = "payment services";
		String data3 = "mumbai,chakala";
		String data4 = data1.concat(" ").concat(data2).concat(" ").concat(data3);
		System.out.println(data4);
	}
}
