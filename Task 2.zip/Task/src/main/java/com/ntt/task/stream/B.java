package com.ntt.task.stream;

public interface B {
void data3();
void data4();
static void data5() {
	System.out.println("static method in interface B");
}
}
