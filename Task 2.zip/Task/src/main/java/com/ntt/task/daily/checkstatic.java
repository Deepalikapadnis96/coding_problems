package com.ntt.task.daily;

public class checkstatic {
	static {
		System.out.println("A");
	}
	{
		System.out.println("B");
	}

	public checkstatic() {
		super();
		System.out.println("C");
	}
	{
		System.out.println("D");
	}
	public static void main(String[] args) {
	checkstatic c= new checkstatic();
	System.out.println("-------");
	checkstatic d= new checkstatic();

	}
}
