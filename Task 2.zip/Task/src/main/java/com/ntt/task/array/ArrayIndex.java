package com.ntt.task.array;

import java.util.stream.IntStream;

public class ArrayIndex {
	public static void main(String[] args) {
		ArrayIndex a = new ArrayIndex();
		int[] arr = { 1, 2, 5, 5, 5, 5, 5, 6 };
		int target = 5;

		int firstIndex = firstIndex(arr, target);
		int lastIndex = lastIndex(arr, target);

		if (firstIndex != -1 && lastIndex != -1) {
			System.out.println("first " + target + ":" + firstIndex);
			System.out.println("last " + target + ":" + lastIndex);

		} else {
			System.out.println(target + " :not found in array");
		}
		
		a.name();
	}

	public static int firstIndex(int[] arr, int target) {
		for (int i = 0; i < arr.length; i++) {
			if (arr[i] == target) {
				return i;
			}
		}
		return -1;
	}

	public static int lastIndex(int[] arr, int target) {
		for (int i = arr.length - 1; i >= 0; i--) {
			if (arr[i] == target) {
				return i;
			}
		}
		return -1;
	}

	public void name() {
		System.out.println("-----------using 8--------");
		int[] array = { 2, 3, 4, 4, 4, 4, 4, 4, 1, 2, 3, 4 };
		int target = 4;
		int first = IntStream.range(0, array.length).filter(i -> array[i] == target).findFirst().orElse(-1);
		int last = IntStream.range(0, array.length).filter(i -> array[i] == target).reduce((a, b) -> b).orElse(-1);
		if (first != -1 && last != -1) {
			System.out.println("first " + target + ":" + first);
			System.out.println("last " + target + ":" + last);

		} else {
			System.out.println(target + " :not found in array");
		}
	}
}