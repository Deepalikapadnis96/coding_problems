package com.ntt.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorTest implements Comparator<ComparatorTest> {
	private int rollNum;
	private String name;

	public int getRollNum() {
		return rollNum;
	}

	public void setRollNum(int rollNum) {
		this.rollNum = rollNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ComparatorTest(int rollNum, String name) {
		super();
		this.rollNum = rollNum;
		this.name = name;
	}

	public ComparatorTest() {

	}

	@Override
	public String toString() {
		return "ComparatorTest [rollNum=" + rollNum + ", name=" + name + "]";
	}

	public int compare(ComparatorTest o1, ComparatorTest o2) {
		if (o1.rollNum > o2.rollNum) {
			return 1;
		} else
			return -1;
	}

}

class sorted implements Comparator<ComparatorTest> {

	public int compare(ComparatorTest o1, ComparatorTest o2) {
		if (o1.getName().length() > o2.getName().length()) 
			return 1;
		//}
		return -1;
	}

}

class test {
	public static void main(String[] args) {
		List<ComparatorTest> c = new ArrayList<ComparatorTest>();
		c.add(new ComparatorTest(1, "deep11111111111111"));
		c.add(new ComparatorTest(3, "aapadnis"));
		c.add(new ComparatorTest(2, "nimba"));
		System.out.println("without sort::" + c);

		Collections.sort(c, new ComparatorTest());
		System.out.println("with sort::" + c);

		System.out.println("-----------------");
		Collections.sort(c, new sorted());
		
		System.out.println("sorted by name>> "+  c);
	}
}
