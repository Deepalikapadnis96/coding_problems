package com.ntt.task.collections;

import java.util.Collections;
import java.util.PriorityQueue;

public class priorityQ {
	public static void main(String[] args) {
		priorityQ.minValue();
		int[] arr = { 11, 33, 49, 50, 19, 8 };
		// max value with top 3 -->>33

		PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
		for (int i = 0; i <= 2; i++) {

			priorityQueue.add(arr[i]);

		}
		for (int i = 3; i < arr.length; i++) {
			if (priorityQueue.peek() < arr[i]) {
				priorityQueue.remove();
				priorityQueue.add(arr[i]);

			}

		}
		System.out.println(priorityQueue.peek());

	}

	// need to take min value so, will used max priority queue
	static void minValue() {
		int[] arr = { 7, 3, 8, 6, 4, 9, 0 };
		// 6
		PriorityQueue<Integer> pq = new PriorityQueue<>(Collections.reverseOrder());
		for (int i = 0; i <= 3; i++) {// 7386
			pq.add(arr[i]);

		}
		for (int i = 4; i < arr.length; i++) {// 490
			if (pq.peek() > arr[i]) {
				pq.remove();
				pq.add(arr[i]);
			}
		}
		System.out.println("min value i.e -->6 :: " + pq.peek());
	}
}
