package com.ntt.task.que;

import java.util.Arrays;
import java.util.stream.IntStream;

public class MissingOneNum {
	public static void main(String[] args) {
		int n = 1000;
		int sum = (n * (n + 1)) / 2;
		int[] num = IntStream.rangeClosed(1, n).toArray();
		System.out.println("sum >>" + Arrays.toString(num));

		num[123] = 0;
		int sum2 = IntStream.of(num).sum();
		System.out.println(sum2);
		int missing = sum - sum2;
		System.out.println(missing);
		MissingOneNum m = new MissingOneNum();
		m.data();
		m.fact();
		m.prime();
	}

	void data() {
		int n = 5;
		int sum = 0;
		for (int i = 1; i <= n; i++) {
			sum = sum + i;
			System.out.println(sum);
		}
		int[] input = { 1, 2, 4, 5 };
		int sum1 = 0;

		for (int j = 1; j <= input.length; j++) {
			sum1 = sum1 + j;
			System.out.println("second>>" + sum1);

		}
		int a2 = sum - sum1;
		System.out.println(a2);
	}

	void fact() {
		int n = 4;
		int fact = 1;
		for (int i = 1; i <= n; i++) {
			fact = fact * i;
		}
		System.out.println("factorial>" + fact);
	}

	void prime() {
	int n= 10;
	int sum=0;
	for(int i=2;i<=10;i++) {
	if(!isprime(i)){
		System.out.println("prime>>"+i);
		sum=+i;
		System.out.println(sum);
	}
	}
	}
	boolean isprime(int n) {
		for(int i=2;i<=Math.sqrt(n);i++) {
			if(n%2==0) {
				return true;
			}
		}
		return false;
		
	}
}
