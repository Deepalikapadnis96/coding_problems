package com.ntt.task.questions;

import java.util.Arrays;

public class Anagram {
	public static void main(String[] args) {
		String d1 = "pop";
		String d2 = "pop1";
		d1 = d1.toLowerCase();
		d2 = d2.toLowerCase();
		if (d1.length() == d2.length()) {
			char[] charArray = d1.toCharArray();
			char[] charArray2 = d2.toCharArray();
			Arrays.sort(charArray);
			Arrays.sort(charArray2);
			boolean result = Arrays.equals(charArray, charArray2);
			if (result) {
				System.out.println(d1 + "and " + d2 + " is anagram");
			} else {
				System.out.println(d1 + " and " + d2 + " is not anagram");

			}
		} else {
			System.out.println(d1 + " and " + d2 + " is not anagram");

		}
	}
}
