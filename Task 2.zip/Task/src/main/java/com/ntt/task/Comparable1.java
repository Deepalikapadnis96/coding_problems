package com.ntt.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Comparable1 {
   public static void main(String[] args) {
      List<Employee> employees = new ArrayList<Employee>();

      employees.add(new Employee(1, 20, "A"));
      employees.add(new Employee(4, 26, "D"));
      employees.add(new Employee(2, 23, "C"));
      employees.add(new Employee(3, 25, "B"));
      employees.add(new Employee(5, 24, "E"));

      //Unordered list
      System.out.println("Unsorted List");
      System.out.println(employees);

      //Sorted by natural order on employee name, 
      //as provide by compareTo method
      Collections.sort(employees);

      //Ordered list
      System.out.println("Sorted List on Name");
      System.out.println(employees);

      //Sorted by id of employees, 
      //as provide by IdComparator
     // Collections.sort(employees, new IdComparator());

      //Ordered list
   
      //Sorted by age of employees, 
      //as provide by AgeComparator
     // Collections.sort(employees, new AgeComparator());

      //Ordered list
   } 
}

class Employee implements Comparable<Employee>{
   private Integer id;
   private int age;
   private String name;

   public Employee(int id, int age, String name){
      this.id = id;
      this.age = age;
      this.name = name;
   }

   public int compareTo(Employee o) { 
      return id.compareTo(o.id);
   }

   public String toString(){
      return "\n[Id: " + id + ", age: " + age + ", name: " + name +" ]";
   }

   public int getId() {
      return id;
   }

   public void setId(int id) {
      this.id = id;
   }

   public int getAge() {
      return age;
   }

   public void setAge(int age) {
      this.age = age;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }
}

//class IdComparator implements Comparator<Employee>{
//   public int compare(Employee o1, Employee o2) {
//      if (o1.getId() < o2.getId()) {
//         return -1; 
//      }else if (o1.getId() > o2.getId()) { 
//         return 1;
//      } else {
//         return 0; 
//      }
//   } 
//}

/*
 * class AgeComparator implements Comparator<Employee>{ public int
 * compare(Employee o1, Employee o2) { if (o1.getAge() < o2.getAge()) { return
 * -1; }else if (o1.getAge() > o2.getAge()) { return 1; } else { return 0; } } }
 */