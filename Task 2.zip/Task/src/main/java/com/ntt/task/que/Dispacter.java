package com.ntt.task.que;

public class Dispacter {
	public static void main(String[] args) {
		Child c = new Child();
		Parent1 p = c;
		c.test();
		p.test();
		c.statictest();
		p.statictest();
	}
}

class Parent1 {
	public static void statictest() {
		System.out.println("Parent.statictest");
	}

	public void test() {
		System.out.println("Parent.test");
	}
}

class Child extends Parent1 {
	public static void statictest() {
		System.out.println("Child.statictest");
	}

	public void test() {
		System.out.println("Child.test");
	}
}
