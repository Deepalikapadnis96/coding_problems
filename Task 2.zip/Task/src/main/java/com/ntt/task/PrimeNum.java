package com.ntt.task;

public class PrimeNum {
public static void main(String[] args) {
	int num=3;
	boolean flag= false;
	for(int j=0;j<=num/2;j++) {
	for(int i=1;i<=num;i++) {
		if(num%2==0) {
			flag=true;
			//break;
			//System.out.println(num/2+">>");
		}
	}
	if(!flag) {
		System.out.println("prime "+num);
	}else {
		System.out.println("not prime" +flag);
	}
}}
}
//if the num is divisible by 1 or itself then it is a prime num i.e 2,11,3,5