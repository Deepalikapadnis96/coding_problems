package com.ntt.task.stream;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class OptionalTest {
	public static void main(String[] args) {
		// of consider the value if we pass a "null" value in of() method then it will
		// thorugh null-pointer exception
		// if excepting the null value then use ofNullable() method for it.
		OptionalTest o = new OptionalTest();
		o.data();
		o.data1();

		System.out.println("=====================ofNullable,isPresent,isEmpty,of,get=======================");
		Optional ofNullable = Optional.ofNullable("data");
		System.out.println(">>" + ofNullable.get());
		Optional<Object> ofNullable2 = Optional.ofNullable(null);
		System.out.println("check present>>" +ofNullable2.isPresent());// will check present then true not presnet return false
		System.out.println(",,,"+ofNullable2.isEmpty());// will check empty return in boolen form

		Optional<String> of = Optional.of("deepali");

		if (of.isPresent()) {
			String string = of.get();
			System.out.println("get value>>" + string);
		} else
			System.out.println("no value");
	}

	public void data() {
		System.out.println("===================if present method====================");
		List<Integer> asList = Arrays.asList(1, 4, 56, 8, 9, 0);
		Optional<List<Integer>> ofNullable = Optional.ofNullable(asList);
		ofNullable.ifPresent(x -> x.forEach(System.out::println));
	}

	// The main difference is orElse() method will be executed always whether source
	// Optional has value or not whereas orElseGet() will be invoked if and only if
	// source optional is an empty or null value.
	public void data1() {
		System.out.println("===================orElse() and orElseGet() Methods====================");
		Optional<Object> empty = Optional.empty();
		Object orElse = empty.orElse(22);
		System.out.println("o/p of orElse>" + orElse);

		Optional<Integer> of = Optional.of(50);
		Integer orElse2 = of.orElse(88);
		Object empty2 = of.orElseGet(() -> 30);
		System.out.println("o/p of orElseGet>" + empty2+" "+ orElse2);

		empty.ifPresentOrElse(x -> System.out.println("if condition of ifPesentOrElse ::" + x),
				() -> System.out.println("Else condition of ifPresent"));

	}
}
