package com.ntt.task.stream;

public interface A {
void data1();
void data2();
}
