package com.ntt.task.designpattern;

public interface Observer {

	void getnotification();
}
