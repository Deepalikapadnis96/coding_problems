package com.ntt.task.questions;

import java.util.HashSet;
import java.util.Set;

public class FirstDuplicate {
	public static void main(String[] args) {
		String str = "abcdabcdd";
		char firstduplicate = firstduplicate(str);
		if (firstduplicate != 0) {
			System.out.println("Repaeted >>" + firstduplicate);
		} else {
			System.out.println("no repeated");
		}

	}

	public static char firstduplicate(String str) {
		Set<Character> set = new HashSet<>();
		for (int i = 0; i < str.length(); i++) {
			char charAt = str.charAt(i);
			if (set.contains(charAt)) {
				return charAt;
			} else {
				set.add(charAt);
			}

		}
		return 0;
	}
}
