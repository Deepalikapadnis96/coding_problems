package com.ntt.task.stream;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.OptionalInt;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class SecondHighest {
	public static void main(String[] args) {

		int[] arr = { 23, 99, 100, 372, 99, 28, 234 };
		Arrays.stream(arr).sorted().skip(5).limit(1).forEach(System.out::println);
		SecondHighest s = new SecondHighest();
		s.data();
		s.data1();
		s.data2();
		s.date3();

		//data4();
	}

	public void data() {
		List<String> list = Arrays.asList("deepali", "monal", "neha", "monal");
		list.stream().distinct().forEach(System.out::println);
	}

	void data1() {
		int[] arr = { 23, 99, 100, 372, 99, 28, 234 };
		int collect= Arrays.stream(arr).distinct().sorted().skip(arr.length - 4).findFirst().getAsInt();
		System.out.println("second highest>>" + collect);

	}

	void data2() {
		int[] arr = { 23, 99, 100, 372, 99, 28, 234 };
		int asInt = Arrays.stream(arr).distinct().boxed().sorted((a, b) -> b - a).skip(2).mapToInt(Integer::intValue)
				.findFirst().getAsInt();
		System.out.println("second highest another>>" + asInt);

	}

	void date3() {

		// Student k list hai - student k object list(name,id , location)
		// exam list attende - id;

		// student jo ki present nhi tha exams m uske location , group by
		// que1-> List<Integer> asList2 = Arrays.asList(2,3,9,2,1,4,588,33,4,621);
		List<Integer> asList = Arrays.asList(2, 3, 5, 2, 1, 4, 588, 33, 4, 22);

		// que->> List<List<Integer>> l1 =
		// Arrays.asList(Arrays.asList(2,3,4,5),Arrays.asList(1,8,9,4));

		List<Integer> collect = asList.stream().sorted((a, b) -> b.compareTo(a)).limit(1).collect(Collectors.toList());
		System.out.println("colect>>" + collect);
	}

//	public static void data4()
//	{
//		List<List<Integer>> l1 = Arrays.asList(Arrays.asList(2, 3, 4, 5), Arrays.asList(1, 8, 9, 4));
//		l1.stream().filter(x -> x.stream().filter(p ->p%2).close()).forEach(System.out.println));
//	}
}
