package com.ntt.task;

import java.util.stream.IntStream;

public class IntstrmIterator {
	public static void main(String[] args) {
		IntstrmIterator it = new IntstrmIterator();
		System.out.println("==========");

		it.strm();
		System.out.println("==========");
		it.even();
	}

	void strm() {
		//(0,10)--->0,1,2,3,4,5,6,7,8,9,10 
		//remainder shld b 0
		//2%2==0 remider zero 2+2=4
		IntStream.rangeClosed(0, 10).filter(x -> x % 2 == 0).map(a -> a + 2).forEach(System.out::println);

		IntStream.range(0,  3).filter(x -> x % 2 == 0).map(x -> x * 3)
				.forEach((x) -> System.out.printf(" range1>> %d", x = x + 2));

		int limit = 5;
		//limit=4
		System.out.println("");
		IntStream.iterate(0, n -> n + 3).limit(limit).forEach(x -> {
			x = x + 2;
			System.out.println(" num>>" + x);
		});
	}

	void even() {
		IntStream.range(2, 100).filter(x -> x % 2 == 0).forEach((x) ->System.out.println( x = x * 2));
		
	}
}
