package com.ntt.task.stream;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class NonDuplicate {
	public static void main(String[] args) {
		String[] str = { "deepali kapadnis" };

		HashSet<String> set = new HashSet<>();
		
		IntStream.iterate(0, i -> str.length).boxed();
		Arrays.stream(str).flatMapToInt(CharSequence::chars).mapToObj(c->(char)c).forEach(System.out::println);
		//System.out.println(">>" + collect);
		NonDuplicate n = new NonDuplicate();
		n.data();
		n.data1("deepalika");
	}
	public List<Character> data1(String s) {
		System.out.println("-----------");
		 List<Character> collect = s.chars().mapToObj(x->(char)x).distinct().collect(Collectors.toList());
		 System.out.println("first >>" + collect);
		 return collect;
		//return s.chars().strdistinct().collect(supplier, accumulator, combiner)
	}

	void data() {
		System.out.println("----in last method-----");
		String str = "Deepali";
		Map<Character, Long> collect = str.chars().mapToObj(x -> (char) x)
				.collect(Collectors.groupingBy(Function.identity(), LinkedHashMap:: new,Collectors.counting()));
		System.out.println(collect);
	}
}
