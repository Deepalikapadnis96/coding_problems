package com.ntt.task.UdemyMain;

import com.ntt.task.Udemy.ObjectOrientedProgramming.MyChar;

public class MyCharMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyChar myChar = new MyChar('a');/// chng vowel and num here
		System.out.println("vowel: " + myChar.isVowel());
		System.out.println("isDigit: " + myChar.isDigit());
		System.out.println("isAlphabate :" + myChar.isAlphabate());

		System.out.println("is Consatant : " + myChar.isConsonant()); // non-vowel
	}

}
