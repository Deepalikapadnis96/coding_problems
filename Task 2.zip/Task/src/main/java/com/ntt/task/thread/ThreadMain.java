package com.ntt.task.thread;

public class ThreadMain {
	public static void main(String[] args) {
		ThreadExtend th = new ThreadExtend();
		th.setName("nothing");//we can keep the name for thread
		th.setDaemon(true);
		//th.start();
		th.run();
		for (int i = 0; i < 3; i++) {
			System.out.println("in main");
		}
	}
}
