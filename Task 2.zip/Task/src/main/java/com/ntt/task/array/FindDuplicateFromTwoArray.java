package com.ntt.task.array;

public class FindDuplicateFromTwoArray {
public static void main(String[] args) {
	int[] arr1= {1,2,3};
	int[] arr2= {2,4,5};
	for(int i=0;i<arr1.length;i++) {
		for(int j = 0 ;j<arr2.length;j++) {
			if(arr1[i]==arr2[j]) {
				System.out.println("match array data>>"+ arr1[i]);
			}
		}
	}
}
}
