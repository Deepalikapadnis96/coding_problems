package com.ntt.task.daily;

public class overide {
	public static void main(String[] args) {
		vechile v = new car();
		v.engine();
	}
}

class vechile {
	void engine() {
		System.out.println("in vechile class");
	}
}

class car extends vechile {
	void engine() {
		super.engine(); //calling parent data
		System.out.println("in car");
	}
}

class bike extends vechile {
	void engine() {
		System.out.println("in bike");
	}
}
