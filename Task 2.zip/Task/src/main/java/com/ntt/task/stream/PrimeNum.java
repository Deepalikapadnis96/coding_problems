package com.ntt.task.stream;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PrimeNum {
	public static void main(String[] args) {
		stream1(8);
		stream2();
	}

	// using stream api
	public static void stream1(int num) {
		System.out.println("-------");
		IntStream.range(2, num).filter(PrimeNum::isprime).forEach(System.out::println);
	}

	private static boolean isprime(int n) {
		return n > 1 && IntStream.range(2, n).noneMatch(i -> n % i == 0);
	}

	public static void stream2() {
		List<Integer> of = List.of(3, 25, 5,7, 99, 74);
		List<Integer> collect = of.stream().filter(PrimeNum::isprime).collect(Collectors.toList());
		System.out.println("list is prime:" + collect);
	}
}
