package com.ntt.task.daily;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class PrimeNum {
	public static void main(String[] args) {
		PrimeNum p = new PrimeNum();
		p.data1();
		stream1(4);
		stream2();
		one();
		int arr[] = { 2, 3, 0, 9, 7, 92 };
		int b = 0;
		for (int i = 0; i < arr.length; i++) {
			boolean isprime = true;
			b = arr[i];
			for (int j = 0; j <= Math.sqrt(b); j++) {
				if (b % 2 == 0) {
					isprime = false;
				}
			}
			if (isprime) {
				System.out.println("isprime :" + arr[i]);
			} else {
				System.out.println("isNot Prime :" + arr[i]);
			}
		}
	}

//for one digit
	void data1() {
		System.out.println("---");
		int n = 7;
		boolean prime = true;
		for (int i = 0; i <= n / 2; i++) {
			if (n % 2 == 0) {
				prime = false;
			}
		}
		if (prime) {
			System.out.println("yes");
		} else {
			System.out.println("not");
		}
	}

	// using stream api
	public static void stream1(int num) {
		System.out.println("-------");
		IntStream.range(2, num).filter(PrimeNum::isprime).forEach(System.out::println);
	}

	private static boolean isprime(int n) {
		return n > 1 && IntStream.range(2, n).noneMatch(i -> n % i == 0);
	}

	public static void stream2() {

		List<Integer> of = List.of(3, 25, 1, 99, 74);
		List<Integer> collect = of.stream().filter(PrimeNum::isprime).collect(Collectors.toList());
		System.out.println("list is prime:" + collect);
	}

	public static void one() {
		int a = 25;
		boolean isprime = true;
		for (int j = 2; j <= a / 2; j++) {
			// System.out.println(">>"+a/j);
			if (a % j == 0) {
				isprime = false;
			}
		}
		if (isprime) {
			System.out.println("prime>>" + a);

		} else {
			System.out.println("not prime>>" + a);

		}
	}
}
