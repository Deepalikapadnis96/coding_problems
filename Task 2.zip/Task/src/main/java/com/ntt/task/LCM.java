package com.ntt.task;

public class LCM {
	public static void main(String[] args) {
		int a = 4;
		int b = 6;
		int lcm;
		
		lcm = (a > b) ? a : b;
		while (true) {

			if (lcm % a == 0 && lcm % b == 0) {
				System.out.println(a);
				System.out.printf("a%d b%d c%d", a, b, lcm);
				break;
			}lcm++;
		}
	}
}
