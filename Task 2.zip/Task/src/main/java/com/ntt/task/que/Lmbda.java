package com.ntt.task.que;

import java.util.ArrayList;
import java.util.function.Consumer;

public class Lmbda {
public static void main(String[] args) {
	ArrayList<String> data = new ArrayList<>();
	data.add("App");
	data.add("mobile");
	//consumer is an interface to stored the lambda exp in variable
	Consumer<String> chck =(n)->{System.out.println("-"+n);};
	data.forEach(chck);
	data.forEach((k) ->{System.out.println(">>"+ k);});
	
}
}
