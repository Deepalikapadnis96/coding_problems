package com.ntt.task.collections;

public class EqualsAndHashcode {
	public static void main(String[] args) {
		Student s1 = new Student("mayur", 26);
		Student s2 = new Student("deepali", 27);
		Student s3 = new Student("neha", 27);
		System.out.println("hashcode>> " + s1.hashCode() + " " + s2.hashCode() + " " + s3.hashCode());
		System.out.println("Equals>> " + s1.equals(s2) + " " + s2.equals(s3) + " " + s3.equals(s1));
	}
}

class Student {
	private String name;
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Student(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj instanceof Student) {
			Student stu = (Student) obj;
			return this.age == stu.age;
		}
		return false;
	}

	
	@Override
	public int hashCode() {
		return age;
	}

}
