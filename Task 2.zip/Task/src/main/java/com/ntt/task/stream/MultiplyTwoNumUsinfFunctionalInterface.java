package com.ntt.task.stream;

public class MultiplyTwoNumUsinfFunctionalInterface {

	public static void main(String[] args) {
		FunInterface1 fInt = ((a, b) -> a * b);
		int multiply = fInt.multiply(6, 5);
		System.out.println("value>>" + multiply);

	}

	@FunctionalInterface
	public interface FunInterface1 {
		public int multiply(int a, int b);
	}

}
