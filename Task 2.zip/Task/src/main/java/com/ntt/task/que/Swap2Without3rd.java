package com.ntt.task.que;

public class Swap2Without3rd {
public static void main(String[] args) {
	int x= 20;
	int y = 30;
	x=x+y;//50
	y=x-y;//50-30=20
	System.out.println(" "+x+" "+y);
	x=x-y;//
	
	//x=(x*y)/(y=x);
	
	System.out.println("x:"+x+"y:"+y);
	
}
}
