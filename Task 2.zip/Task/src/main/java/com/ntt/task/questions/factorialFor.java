package com.ntt.task.questions;

import java.util.Scanner;

public class factorialFor {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("-enter->");
	int nextInt = sc.nextInt();
	int x=1;
	for (int i=1;i<=nextInt;i++) {
		x *=i;
		
	}System.out.println("output->"+x);
}
}
