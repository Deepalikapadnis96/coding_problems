package com.ntt.task.daily;

import java.util.Arrays;
import java.util.stream.IntStream;

public class Reverse {
	public static void main(String[] args) {
		Reverse R = new Reverse();
		R.one();
		R.two();
		R.arr();
		R.three();
		R.four();
		R.five();
		R.swapp();
	}

	void one() {
		String a = "deepali";
		String b = "";
		for (int i = 0; i < a.length(); i++) {
			char charAt = a.charAt(i);
			b = charAt + b;
		}
		System.out.println(b);
	}

	void two() {
		String[] a = { "deepali", "nimba", "kapadnis" };
		String b = "";

		for (int i = a.length - 1; i >= 0; i--) {
			b = b + " " + a[i];

		}
		System.out.println(b);
	}

//output in array but using 2 arrays
	void arr() {
		String[] a = { "deepali", "monal" };
		String[] b = new String[a.length];
		int count = 0;
		for (int i = a.length - 1; i >= 0; i--) {
			b[count] = a[i];
			count++;
		}
		System.out.println("arrr>>" + Arrays.toString(b));

	}

//output in array using swap method
	void swapp() {
		System.out.println("-----------");
		String[] a = { "deepali", "nimba", "kapadnis" };
		reverseArray(a);

		for (int i = 0; i < a.length; i++) {
		}
		System.out.println("swapp>"+Arrays.toString(a));

	}

	void reverseArray(String[] array) {
		int left = 0;
		int right = array.length - 1;// 2 i.e kapadnis
		while (left < right) { // 0<2
			String temp = array[left];// depali
			array[left] = array[right];// 2
			array[right] = temp;
			left++;// 1
			right--;
		}
	}

	void three() {
		int a = 12345;
		int rev = 0;
		int rem = 0;
		// int num =a;
		while (a != 0) {
			rem = a % 10;
			rev = rev * 10 + rem;
			a /= 10;
		}

		System.out.println("three>>" + rev);
	}

	void four() {
		int[] a = { 1, 23, 4, 9 };
		for (int j = a.length - 1; j >= 0; j--) {
			System.out.printf("four>>" + a[j] + "");
		}
	}

	void five() {
		System.out.println("");
		String[] s = { "deepali", "kapadnis" };
		IntStream.iterate(s.length - 1, dec -> dec - 1).limit(s.length).forEach(x -> {
			System.out.printf(" five>>" + s[x]);
		});
	}
}
