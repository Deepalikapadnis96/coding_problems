package com.ntt.task;

public class StringCompareTo {
	public static void main(String[] args) {

		String s1 = "deepali";
		String s2 = "";
		String s3 = "me";
		System.out.println("compare to: " + s1.compareTo(s2));
		System.out.println(s2.compareTo(s3));
	}
}
