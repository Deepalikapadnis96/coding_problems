package com.ntt.task.card;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DeckOfCards {
	private final List<Cards> cards;

	public List<Cards> getCards() {
		return cards;
	}

	public DeckOfCards() {
		cards = new ArrayList<>();
		for (Suits suit:Suits.values()) {
			for (Rank rank: Rank.values()) {
				cards.add(new Cards(suit, rank));
			}
		}
		Collections.shuffle(this.cards);
		
	}
	
	

	public void sortDeck() {
		cards.sort(new Comparator<Cards>() {

			@Override
			public int compare(Cards card1, Cards card2) {
				// TODO Auto-generated method stub
				int compareTo = card1.getSuits().compareTo(card2.getSuits());
				return card1.getRank().getValue()-card2.getRank().getValue();
			}
		});
	}
}
