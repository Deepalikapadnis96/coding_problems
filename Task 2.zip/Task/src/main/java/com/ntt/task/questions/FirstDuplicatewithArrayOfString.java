package com.ntt.task.questions;

public class FirstDuplicatewithArrayOfString {
/**
 * @param args
 */
public static void main(String[] args) {
	String str = "deepali kapadnis";
	char[] charArray = str.toCharArray();
	for(int i=0; i<charArray.length;i++) {
		for(int j=i+1;j<charArray.length;j++) {
			if(charArray[i]==charArray[j]) {
				System.out.println("duplicates>>"+charArray[j]);
			}
		}
	}
}
}
