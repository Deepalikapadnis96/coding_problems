package com.ntt.task.stream;

public class C implements A, B {
	public static void main(String[] args) {
		C c = new C();
		c.data1();
		c.data2();
		c.data3();
		c.data4();
		B.data5();
	}

	@Override
	public void data1() {
		System.out.println("interface A one method");
	}

	@Override
	public void data2() {
		System.out.println("interface A  method1");

	}

	@Override
	public void data3() {
		System.out.println("interface B  method2");

	}

	@Override
	public void data4() {
		System.out.println("interface A with method 4");
	}

	
}
