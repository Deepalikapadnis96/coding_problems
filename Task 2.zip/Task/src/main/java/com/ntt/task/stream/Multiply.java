package com.ntt.task.stream;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Multiply {
	public static void main(String[] args) {
		int[] num = { 2, 3 };
		int reduce = Arrays.stream(num).reduce(1, (a, b) -> a * b);
		System.out.println(reduce);
		Multiply m = new Multiply();
		m.mul1(4);
		m.wholeTable(2);
	}
	void mul1(int n) {
		int reduce = IntStream.rangeClosed(1, n).reduce(1,(a,b)->a*b);
		System.out.println(reduce);
	}
	void wholeTable(int n) {
		IntStream.rangeClosed(1, 10).forEach(i->System.out.println(n+"*"+i+"="+(n*i)));
	}
}
