package com.ntt.task.lambda;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import com.ntt.task.pojo.EmployeeDetails;

public class GroupingBy {
	public static void main(String[] args) {
		List<EMployee> emp = new ArrayList<>();
		emp.add(new EMployee(1, "deepali", "100"));
		emp.add(new EMployee(2, "mayur", "110"));
		emp.add(new EMployee(3, "neha", "111"));
		emp.add(new EMployee(4, "harshit", "112"));
		emp.add(new EMployee(4, "hrithik", "113"));

		// it will give you name and salary soring name alphabaticallly
		TreeMap<String, List<String>> collect = emp.stream().collect(Collectors.groupingBy(EMployee::getName,
				TreeMap::new, Collectors.mapping(EMployee::getSalary, Collectors.toList())));

		System.out.println("only name and salary display >>" + collect);

		System.out.println("----------------------------------------");

		// it will display all the data on the basis of getId
		Map<Integer, List<EMployee>> collect2 = emp.stream().collect(Collectors.groupingBy(EMployee::getId));
		System.out.println("all the data will get display >>" + collect2);

		System.out.println("----------------------------------------");

		Map<Integer, List<String>> collect3 = emp.stream().collect(
				Collectors.groupingBy(EMployee::getId, Collectors.mapping(EMployee::getName, Collectors.toList())));
		System.out.println(" map >> " + collect3);

		System.out.println("----------------------------------------");
		Map<Integer, Long> collect4 = emp.stream()
				.collect(Collectors.groupingBy(EMployee::getId, Collectors.counting()));
		System.out.println("countting>> " + collect4);

		System.out.println("----------------------------------------");
		 Map<Integer, List<EMployee>> collect5 = emp.stream().collect(Collectors.groupingBy(EMployee::getId));
		System.out.printf("Total time for sequential process: %sms\n", System.currentTimeMillis());

		Map<Integer, List<EMployee>> collect6 = emp.parallelStream().collect(Collectors.groupingByConcurrent(EMployee::getId));
		System.out.println("time>>"+ System.currentTimeMillis()+ " >>" + collect6);

	}
}