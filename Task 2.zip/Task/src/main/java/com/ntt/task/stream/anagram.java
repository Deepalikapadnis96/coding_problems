package com.ntt.task.stream;

import java.util.Arrays;

public class anagram {
public static void main(String[] args) {
	String str="slient";
	String str1 ="listen";
	boolean anagram1 = anagram.isAnagram(str, str1);
	System.out.println(str + " && " +str1 +"is anagram " +anagram1);
	
}
public static boolean isAnagram(String x, String y) {
	if(x.length()!=y.length()) {
		return false;
	}
	return Arrays.equals(x.chars().sorted().toArray(), y.chars().sorted().toArray());
}
}
