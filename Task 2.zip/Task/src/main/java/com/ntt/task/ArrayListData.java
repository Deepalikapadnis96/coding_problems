package com.ntt.task;

import java.util.ArrayList;

public class ArrayListData {

	public static void main(String[] args) {
		ArrayList<String> names = new ArrayList<String>();
		names.add("deepali");
		names.add("monta");
		System.out.println("List: " + names);
		System.out.println('D'+'E'+'L');
 }
}
