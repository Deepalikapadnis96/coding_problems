package com.ntt.task;

public class Que5PrimeNumber {
	public static void main(String[] args) {
		// int array[] = { 22, 23, 7, 12, 9 };
		int num = 3;
		int temp = 0;
		for (int i = 0; i <= (num / 2); i++) {
			if ((num % 2) == 0) {//to check reminder
				temp = temp + 1;
				System.out.println("data: " + temp);
			}
		}
		//System.out.println("loop:" + (num - 1));
		if (temp > 0) {
			System.out.println("not prime:");
		} else {
			System.out.println("prime");
		}
	}
	}

