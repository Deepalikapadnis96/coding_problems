package com.ntt.task.que;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class RmvDuplicateElementFromArrayAndSortSingl {
	
	/*public static void main(String[] args) {
		int[] arr = { 1, 1, 2, 3, 3, 6, 7, 7, 8 };
		data(arr);
		
	}

	public static<T extends Comparable<T>> void data(int[] arr) {
		Set<Integer> element = new HashSet<>();
		for(int arr1:arr) {
			if(!element.add(arr1)) {
				System.out.println(">>" + arr1);

			}
		}
		//for (int i = 0; i < arr.length; i++)
			//element.add(arr[i]);
		//System.out.println(">>" + element);
	}
	*/
	public static void main(String[] args) {

        //1st method 
        int[] arr= {1,3,1,1,2,2,3,4,5,5,2};
        int count = 0;
        Arrays.sort(arr);
        for(int i=0; i<arr.length-1;i++) {
            if(arr[i]==arr[i+1]) {
                count = count+1;
                if(count==1) {
                System.out.println(arr[i]);
                }

            }else {
                count=0;
            }
        }
    }
}
