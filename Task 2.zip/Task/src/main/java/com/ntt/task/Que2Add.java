package com.ntt.task;

public class Que2Add {
	
	public static void main(String[] args) {
		int[] arr = { 3, 43, 5, 88, 3 };
		int sum = 0;
		for (int element : arr) {   
			sum+=element;
		}
		System.out.println("addition:" + sum);
	}
}