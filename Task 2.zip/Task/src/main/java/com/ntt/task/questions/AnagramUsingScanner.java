package com.ntt.task.questions;

import java.util.Arrays;
import java.util.Scanner;

import com.ntt.task.que.arrayOfStringWithFirstLetter;

public class AnagramUsingScanner {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter str 1:");
		String str1 = sc.nextLine();
		System.out.println("enter str 2:");
		String str2 = sc.nextLine();

		str1.toLowerCase();
		str2.toLowerCase();
		if (str1.length() == str2.length()) {
			char[] charArray = str1.toCharArray();
			char[] charArray2 = str2.toCharArray();
			Arrays.sort(charArray);
			Arrays.sort(charArray2);
			boolean result = Arrays.equals(charArray, charArray2);
			if (result) {
				System.out.println(str1 + " and " + str2 + " are anagram");
			} else {
				System.out.println(str1 + " and " + str2 + " are not anagram");

			}
		} else {
			System.out.println(str1 + " and " + str2 + "are not anagram");

		}

	}
}
