package com.ntt.task.stream;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class WithoutGroupinBy {
	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(2, 3, 4, 5, 6, 6, 5, 4, 3, 2, 2, 23, 4, 4, 5, 6, 2);
		HashMap<Integer, Integer> map = new HashMap<>();

		for (Integer data : list) {
			map.put(data, map.getOrDefault(data, 0) + 1);
		}
		map.forEach((x, y) -> System.out.println("key " + x + "::" + " value " + y));
		
		WithoutGroupinBy w = new WithoutGroupinBy();
		w.a1();
		w.a2();
	}

	void a1() {
		System.out.println("=====================");
		List<Integer> list = Arrays.asList(3, 5, 6, 7, 8, 7, 6, 5, 4, 3, 3, 1, 1, 3, 3, 3);
		HashMap<Integer, Integer> map = new HashMap<>();
		for (Integer data : list) {
			map.put(data, map.getOrDefault(data, 0) + 1);
		}
		map.forEach((x, y) -> System.out.println(x + " :: " + y));
	}
	void a2() {
		System.out.println("=====================");
		List<String> list = Arrays.asList("deepali","deep","monal","deep","neha","neha");
		HashMap<String, Integer> map = new HashMap<>();
		for(String data: list) {
			map.put(data, map.getOrDefault(data, 0)+1);
	}
		map.forEach((x,y)->System.out.println("name >"  +x+"," + " value> "+y));

	}
}
