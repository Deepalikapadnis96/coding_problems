package com.ntt.task.lambda;

public class Reverse {
public static void main(String[] args) {
	Ddata ref=(str)->{
		String result ="";
		for(int i=str.length()-1;i>=0;i--) 
			//length=0,1,2,3
			//length-1=3-1=2 >=0
			//i--=2; 2-1=1 >=0 ==>1;1-1=0 >=0
			result = result + str.charAt(i);
		System.out.println(result);
		return result; 
	};
    System.out.println("Lambda reversed = " + ref.reverse("abcd"));

}
}

@FunctionalInterface
interface Ddata {
	String reverse(String n);
}
