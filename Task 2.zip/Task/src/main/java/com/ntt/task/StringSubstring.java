package com.ntt.task;

public class StringSubstring {

	public static void main(String[] args) {
		// We pass beginIndex and endIndex number position in the Java substring method
		// the beginIndex starts from 0, whereas the endIndex starts from 1.
		// StringIndexOutOfBoundsException is thrown when any one of the following
		// conditions is met.

		// if the start index is negative value
		// end index is lower than starting index.
		// Either starting or ending index is greater than the total number of
		// characters present in the string.
		String s1 = "data is not present in the given string";
		System.out.println("data >> " +s1.substring(0));
		System.out.println(s1.substring(5, 18));
		// System.out.println(s1.substring(4, 45));// outOfBound cz it is not upto 45

		String[] str = { "deepali kapadnis", "shital kapadnis", "mayur pawar" };
		String surname = "kapadnis";
		int size = surname.length();
		for (int i = 0; i < str.length; i++) {
			int len = str[i].length();
			String subString = str[i].substring(len - size);
			if (subString.equals(surname)) {
				System.out.println(str[i]);
			}
		}
	}
}
