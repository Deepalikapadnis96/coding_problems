package com.ntt.task.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ShortCircuitOpr {
//intermediate=limit() -->takes one arg and return stream
	// Terminal = findFirst(),findAny(),allMatch(),noneMatch()
	public static void main(String[] args) {

		List<String> list = new ArrayList<>();
		list.add("A1");
		list.add("AC");
		list.add("A9");

		list.add("BE");
		list.add("BW");
		list.add("BO");

		list.add("C1");
		list.add("C2");
		list.add("C3");
		list.add("F");
		list.add("G");

		list.stream().limit(4).forEach(System.out::println);

		// findFIrst()
		Stream<String> limit = list.stream().limit(9);
		String string = limit.filter(x -> x.contains("B")).findFirst().get();
		System.out.println("find-First>>" + string);

		// findAny() required parallel() will return any elemnt rather then first
		// element
		String string2 = list.stream().parallel().limit(7).filter(x -> x.contains("A")).findAny().get();
		System.out.println("find-Any>>" + string2);

		// AnyMatch will return true bcz there is match
		Stream<String> stream = list.stream();
		System.out.println("any-Match>>" + stream.anyMatch(x -> x.contentEquals("C3")));

		// AllMatch it will return boolean will return false bcz all the argument shld have A 
		Stream<String> stream2 = list.stream();
		System.out.println("All-Match>>" + stream2.allMatch(x -> x.contains("A")));
		
		//noneMatchh()
		Stream<String> stream3 = list.stream();
		System.out.println("none-Match>>" +stream3.noneMatch(x-> x.contains("C2")));
	}
}
