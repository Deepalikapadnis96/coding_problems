package com.ntt.task.que;

import java.util.Optional;

public class PrintNumberOfLetterFromString1 {
	public static void main(String[] args) {
		String data = null;
		Optional<String> s = Optional.ofNullable(data);
		if (s.isPresent()) {
			String string = s.get();
			System.out.println(string);
			int countdata = countdata(data);
			System.out.println("num of letters" + countdata);

		} else {
			System.out.println("not present");
		}
	}

	public static int countdata(String str) {
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			if (Character.isLetter(str.charAt(i))) {
				count++;
			}
		}
		return count;
	}
}
