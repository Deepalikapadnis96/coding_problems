package com.ntt.task.card;

public class CardComparator {
	public Cards compare(Cards card1, Cards card2) {
		if (card1 == null || card2 == null) {
			throw new IllegalArgumentException("null data");
		}
		return card1.getRank().getValue() > card2.getRank().getValue() ? card1 : card2;
	}
}
