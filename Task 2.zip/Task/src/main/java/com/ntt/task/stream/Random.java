package com.ntt.task.stream;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Random {
public static void main(String[] args) {
	Stream<Integer> str = Stream.generate(()->(new java.util.Random()).nextInt(100));
	str.limit(6).forEach(System.out::println);
	
	System.out.println("-------------------->>>>>");
	
	IntStream ints= "abcnc".chars();
	ints.forEach(System.out::println);
	
	System.out.println("-------------------->>>>>");

	Stream<String> str1 = Stream.of("A_b_c".split("_"));
	str1.forEach(System.out::println);
	
	System.out.println("-------------------->>>>>");

}
}
