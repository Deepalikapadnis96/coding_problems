package com.ntt.task;
//package com.ntt.ots.testAPI.service;
//package com.ntt.ots.testAPI.Transaction;
//
//import org.apache.log4j.Logger;
//
//import com.atom.ots.signature.AtomSignature;
//import com.ntt.ots.testAPI.to.TransactionTo;
//
//import lombok.extern.java.Log;
//
//@Log
//public class Signature {
//	Logger logger   = Logger.getLogger(Signature.class.getName());
//	
//	public static String generateSignature(TransactionTo req) {
//		
//		String signatureKey = req.getReqHashKey();
//		log.info("reqKey : " + signatureKey);
//		
//		String signatureString = req.getLogin() + req.getPass() + req.getTtype() + req.getProdid() + req.getMerchTxnId()
//				+ req.getAmt() + req.getTxncurr();
//		log.info("signatureString " + signatureString);
//		
//		String atomSignature = AtomSignature.generateSignature(signatureKey, signatureString);
//		log.info("atomSignature : " + atomSignature);
//		
//		return atomSignature;
//
//	}
//
//}
