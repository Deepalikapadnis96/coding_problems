package com.ntt.task.daily;

import java.util.stream.IntStream;

public class factorial {
	public static void main(String[] args) {
		factorial f = new factorial();
		f.one();
		f.two();
		f.three();
		f.four(3);
	}

	void one() {
		int a = 4;
		int fact = 1;
		for (int i = 1; i <= a; i++) {
			fact = fact * i;
		}
		System.out.println("one>>" + fact);
	}

	void two() {
		int[] a = { 2, 3, 4, 5, 6 };
		int b;
		for (int i = 0; i < a.length; i++) {
			int fac = 1;
			b = a[i];
			// System.out.println(b);
			for (int j = 1; j <= b; j++) {
				// System.out.println(b);
				fac = fac * j;
			}
			System.out.println("two>>" + fac);
		}
	}

	void three() {
		int a = 5;
		int i = 1;
		int fact = 1;
		while (i <= a) {
			fact *= i;
			i++;
		}
		System.out.println("three>>" + fact);
	}

	void four(int end) {
		int reduce = IntStream.rangeClosed(1, end).reduce(1, (x, y) -> x * y);
		System.out.println("four>>" + reduce);

	}
}
