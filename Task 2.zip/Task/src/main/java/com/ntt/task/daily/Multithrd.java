package com.ntt.task.daily;

public class Multithrd extends Thread {
	    public void run(){
	        System.out.println("Running Thread Name: "+ this.currentThread().getName());
	        System.out.println("Running Thread Priority: "+ this.currentThread().getPriority());
	    }
}
	 class data{
	    public static void main(String[] args) {
	    	Multithrd multiThread1 = new Multithrd();
	        multiThread1.setName("First Thread");
	        multiThread1.setPriority(Thread.MIN_PRIORITY);

	        Multithrd multiThread2 = new Multithrd();
	        multiThread2.setName("Second Thread");
	        multiThread2.setPriority(Thread.MAX_PRIORITY);

	        Multithrd multiThread3 = new Multithrd();
	        multiThread3.setName("Third Thread");

	        multiThread1.start();
	        multiThread2.start();
	        multiThread3.start();
	    }
	}
