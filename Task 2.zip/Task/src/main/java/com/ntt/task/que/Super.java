package com.ntt.task.que;

public class Super {
	public static void main(String[] args) {

		Child1 c = new Child1();
		c.A1();
	}
}

class Parent {
	void A1() {
		System.out.println("in parent A method");
	}
}

class Child1 extends Parent {

	void A1() {
		super.A1(); 
		System.out.println("method in chlid:");
	}

}
