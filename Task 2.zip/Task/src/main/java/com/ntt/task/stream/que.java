package com.ntt.task.stream;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class que {
	public static void main(String[] args) {
		List<emp> asList = Arrays.asList(new emp("deepali", 27, 77L), new emp("hrithik", 24, 55L),
				new emp("harshit", 26, 22L));
		Map<String, Integer> collect = asList.stream().filter(x -> x.getAge() > 25)
				.sorted(Comparator.comparing(emp::getAge)).collect(Collectors.toMap(emp::getName, emp::getAge));
		System.out.println(">>"+collect);

		que a = new que();
		a.data();
		a.data1();
	}

	void data() {
		List<emp> asList = Arrays.asList(new emp("deepali", 27, 77L), new emp("hrithik", 24, 55L),
				new emp("harshit", 26, 22L));
		List<emp> collect = asList.stream().filter(x -> x.getAge() > 25).collect(Collectors.toList());
		collect.forEach(System.out::println);
	}

	void data1() {
		List<emp> asList = Arrays.asList(new emp("deepali", 27, 77L), new emp("hrithik", 24, 55L),
				new emp("harshit", 26, 22L));
		  asList.stream().map(emp::getSalary).distinct().sorted((s, s1) -> Long.compare(s1, s))
				.skip(1).findFirst().ifPresent(salary-> System.out.println(" 2nd highest salary>>" + salary));
		  
		  System.out.println("<--------Another Solution-------->");
	
		  Long long1 = asList.stream().map(emp::getSalary).distinct().sorted((s, s1) -> Long.compare(s1, s))
			.skip(1).findFirst().get();
		  System.out.println("second highest salary>> " + long1);
	}
}
