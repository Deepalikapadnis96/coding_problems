package com.ntt.task.collections;

import java.util.ArrayList;

public class SequencedCollections {
public static void main(String[] args) {
	//Sequen
	ArrayList<Integer> list = new ArrayList<>();
	list.add(0);
	//list.add
}
}
