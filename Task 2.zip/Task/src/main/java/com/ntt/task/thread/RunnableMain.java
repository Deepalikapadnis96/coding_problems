package com.ntt.task.thread;

public class RunnableMain {
public static void main(String[] args) {
	RunnableImpl rn = new RunnableImpl();
	Thread th = new Thread(rn);
	th.start();
	
	for(int i=0;i<2;i++) {
		System.out.println("in runnable main");
	}
}
}
