package com.ntt.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Comparable2 implements Comparable<Comparable2> {
	private int id;
	private String name;

	public Comparable2(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Comparator [id=" + id + ", name=" + name + "]";
	}

//	public int compareTo(Comparable2 c) {
//		return name.compareTo(c.name);
//	}
	//@Override
	public int compareTo(Comparable2 o) {
		if(this.id>o.id)
			return 1;
		else
		return -1;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

class check {
	public static void main(String[] args) {
		List<Comparable2> comp = new ArrayList<Comparable2>();
		comp.add(new Comparable2(7, "peep"));
		comp.add(new Comparable2(2, "neha"));
		System.out.println("not sorted " + comp);
		Collections.sort(comp);
		System.out.println("sorted>>"+comp);
	}
}
