package com.ntt.task.que;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateWordsFromString {
	public static void main(String[] args) {
		
	
	String[] stringdata = {"deepali","jui","pooja","jui"};

	 Set<String> rmDuplicate =  new LinkedHashSet<String>(Arrays.asList(stringdata));
	 System.out.println(rmDuplicate);
	 String[] array = rmDuplicate.toArray(new String[rmDuplicate.size()]);
	 System.out.println("remove duplications: " + Arrays.toString(array));
}
}
