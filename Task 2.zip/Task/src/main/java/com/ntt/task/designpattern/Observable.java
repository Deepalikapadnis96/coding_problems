package com.ntt.task.designpattern;

public interface Observable {

	void subscriberadd(Observer obs);
	void unsubscribe(String obs);
	void notified();
}
