package com.ntt.task.daily;

public class vowel {
public static void main(String[] args) {
	vowel v= new vowel();
	v.one();
}
void one() {
	String a= "DEEPALI KAPADNIS";
	for(int i=0; i<a.length();i++) {
		
	
			if((a.charAt(i)=='A')||
					(a.charAt(i)=='E')||(a.charAt(i)=='I')||(a.charAt(i)=='O')||(a.charAt(i)=='U')) {
				System.out.println("vowel"+a.charAt(i));
			}else {
				System.out.println("Constant:"+a.charAt(i));
			}
	}
}
}
