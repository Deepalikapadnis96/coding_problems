package com.ntt.task.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamList {
public static void main(String[] args) {
	List<Integer> list = new ArrayList<>();
	for(int i=1;i<10;i++) {
		list.add(i);
	}
		 list.stream().forEach(System.out::println);
		 Stream.generate(() -> "element").limit(4).forEach(System.out::println);
		 Stream.iterate(40, n -> n + 2).limit(4).forEach(System.out::println);
}
}
