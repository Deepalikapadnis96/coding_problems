package com.ntt.task.que;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;

public class CountLetterFromStringUsingMap {
	public static void main(String[] args) {
		String data = "deepali kapadnis";
		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();
		char[] charArray = data.toCharArray();
		System.out.println(">>" + Arrays.toString(charArray));
		for (char dd : charArray) {
		//	if (map.containsKey(dd)) {
				map.put(dd, map.getOrDefault(dd, 0) + 1);
			} //else {
//				map.put(dd, 1);
//			}
		//}
		for (Entry<Character, Integer> entry : map.entrySet()) {
			if (entry.getValue() > 1) {
				System.out.println("key:" + entry.getKey() + " value:" + entry.getValue());
			}
		}
		CountLetterFromStringUsingMap cc = new CountLetterFromStringUsingMap();
		cc.check();
	}

	public void check() {
		String str = "deepali kapadnis";
		Map<Character, Integer> mapaData = new HashMap<Character, Integer>();
		char[] charArray = str.toCharArray();
		for (char loop : charArray) {
			if (mapaData.containsKey(loop)) {
				mapaData.put(loop, mapaData.get(loop) + 1);
			} else {
				mapaData.put(loop, 1);
			}
		}
		for (Entry<Character, Integer> entry : mapaData.entrySet()) {
			if (entry.getValue() > 1) {
				System.out.println("key" + entry.getKey() + "value" + entry.getValue());
			}
		}
	}
}