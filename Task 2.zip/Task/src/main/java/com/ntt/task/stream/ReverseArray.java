package com.ntt.task.stream;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ReverseArray {
	public static void main(String[] args) {
		int[] arr = { 2, 3, 4, 5, 6 };
		int[] b = IntStream.rangeClosed(1, arr.length).map(i -> arr[arr.length - i]).toArray();
		System.out.println(Arrays.toString(b));

		ReverseArray.reverse(arr);
		System.out.println("==========space complexity better========");
		ReverseArray.data(arr);
		System.out.println(Arrays.toString(arr));
		System.out.println("==========occurance========");
		String str="deepaliKapadnis";
		ReverseArray.data1(str);
		System.out.println("==========better time and space complexity occurance========");
		ReverseArray.data2(str);

		
	}

	public static void reverse(int[] arr) {
		System.out.println("================================");
		List<Integer> collect = Arrays.stream(arr).boxed().collect(Collectors.toList());
		Collections.reverse(collect);
		int[] array = collect.stream().mapToInt(Integer::intValue).toArray();
		System.out.println("reverse>>" + Arrays.toString(array));
	}

	public static void data(int[] a) {

		int length = a.length;
		for (int i = 0; i < length / 2; i++) {
			int temp = a[i];
			a[i] = a[length - i - 1];
			a[length - 1 - i] = temp;

		}
	}

	public static void data1(String s) {
	Map<Character, Long> map=	s.toLowerCase().chars().mapToObj(x -> (char) x)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
	System.out.println(map);
	}
	
	public static void data2(String s) {
		Map<Character, Long>map= new HashMap<>();
		String lowerCase = s.toLowerCase();
		for(char c : lowerCase.toCharArray()) {
			map.put(c, map.getOrDefault(c, 0L)+1);
		}
		System.out.println(map);
		
	}

}
