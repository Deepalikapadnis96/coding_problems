package com.ntt.task.Encryption;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class crypt {
	public static void main(String[] args) throws NoSuchAlgorithmException, IllegalBlockSizeException,
			BadPaddingException, InvalidKeyException, NoSuchPaddingException {

		SecretKey secretKey = KeyGenerator.getInstance("AES").generateKey();
		Cipher encryptionCiper = Cipher.getInstance("AES");
		encryptionCiper.init(Cipher.ENCRYPT_MODE, secretKey);
		//AmexPayload amexPayload = new AmexPayload();
		//String merchantId = amexPayload.getTransactionData().getMerchantId();
		//String password = amexPayload.getTransactionData().getPassword();
		String merchantId = "198";
		String password ="simpledata";
		String text = merchantId+password;
		byte[] textInByte = text.getBytes(StandardCharsets.UTF_8);
		byte[] encBytes = encryptionCiper.doFinal(textInByte);
		String encBase64 = Base64.getEncoder().encodeToString(encBytes);
		System.out.println("encdata:" + encBase64);
		Cipher decryptionCiper = Cipher.getInstance("AES");
		decryptionCiper.init(Cipher.DECRYPT_MODE, secretKey);
		byte[] decodeByte = Base64.getDecoder().decode(encBase64);
		byte[] decBytes = decryptionCiper.doFinal(decodeByte);
		String decText = new String(decBytes, StandardCharsets.UTF_8);
		System.out.println("decData:" + decText);
	}
}
