package com.ntt.task.stream;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class DuplicateNameFromString {
	public static void main(String[] args) {

		List<String> asList = Arrays.asList("deepali", "monal", "neha", "monal", "priya", "pooja", "priya");

		System.out.println("==============distinct===============");
		asList.stream().distinct().collect(Collectors.toList()).forEach(System.out::println);

		System.out.println("==============frequency===============");
		asList.stream().filter(x -> Collections.frequency(asList, x) > 1).collect(Collectors.toSet())
				.forEach(System.out::println);

		System.out.println("=================set===================");
		HashSet<String> s = new HashSet<>();
		asList.stream().filter(x -> !s.add(x)).collect(Collectors.toSet()).forEach(System.out::println);

		System.out.println("================groupingBy=============");
		Map<String, Long> collect = asList.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println("grouping output>>" + collect);

		 Set<Entry<String, Long>> collect2 = collect.entrySet().stream().filter(x -> x.getValue() > 1)
				.collect(Collectors.toSet());
		System.out.println("grouping output 2 >>" + collect2);
		
		DuplicateNameFromString.data();


	}

	static void data() {
		System.out.println("repeated char with count");
		char[] arr = { 'x', 'z', 'v', 's', 'z', 'x' };
		Map<Character, Long> collect = new String(arr).chars().mapToObj(x -> (char) x)
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		collect.entrySet().stream().filter(entry -> entry.getValue() > 1)
				.forEach(entry -> System.out.println("key>" + entry.getKey() + " value>" + entry.getValue()));
	}
}