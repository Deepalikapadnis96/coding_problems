package com.ntt.task.stream;

import java.util.stream.LongStream;

public class Factorial {
public static void main(String[] args) {
	long calculate = Factorial.calculate(3);
	System.out.println(calculate);
}
public static long calculate(int n) {
	if(n<0) {
		throw new IllegalArgumentException();
	}
	return LongStream.rangeClosed(1, n).reduce(1,(long a, long b)->a*b);
}
}

//LongStream.range(1, 5)-->1,2,3,4
//LongStream.rangeClosed(1, 5)--> 1,2 3,4,5