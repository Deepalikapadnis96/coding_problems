package com.ntt.task.daily;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class eve {
	public static void main(String[] args) {
		eve e = new eve();
		e.one();
		e.two();
		e.three(2, 60);
		e.four(2, 9);
		e.five();
		

		
		String ch ="deepali";
		ch.chars().mapToObj(x->(char)x)
		.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()))
		.forEach((a,b)-> System.out.println(a+" value>>"+b));
	}

	void one() {
		int[] a = { 21, 38, 0, 9, 28, 7, 8, 3, 2, 4 };
		for (int i = 0; i < a.length; i++) {
			if (a[i] % 2 == 0) {
				System.out.println("one even::" + a[i]);
			} else if (a[i] % 2 == 1) {
				System.out.println(" one odd::" + a[i]);

			}
		}
	}

	void two() {
		int a = 49;
		if (a % 2 == 0) {
			System.out.println("two even::" + a);
		} else {
			System.out.println("two odd::" + a);

		}
	}

	void three(int start, int end) {
		IntStream.range(start, end).filter(x -> x % 2 == 0).forEach(System.out::println);

	}

	void four(int start, int end) {
		IntStream.range(start, end).forEach(x -> {
			if (x % 2 == 0) {
				System.out.println("four even::" + x);
			} else {
				System.out.println("four odd::" + x);

			}
		});
	}

	void five() {
		List<Integer> asList = Arrays.asList(2, 4, 5, 6, 7, 85, 49, 30, 29, 39, 85);
		asList.stream().filter(x -> x % 2 == 1).forEach(System.out::println);
	}
}
