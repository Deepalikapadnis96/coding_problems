package com.ntt.task;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Student implements Comparator<Student> {
	int age;
	String name;

	@Override
	public String toString() {
		return "Student [age=" + age + ", name=" + name + "]";
	}

	public Student(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}

	public Student() {

	}

	public int compare(Student o1, Student o2) {
		if (o1.age > o2.age)
			return 1;

		return -1;
		// return 0;
	}

}

class Sortbyname implements Comparator<Student> {

	public int compare(Student A, Student B) {
		/*
		 * Comparator<Student> student =(Student A,Student B)-> { return
		 * A.age>B.age?1:-1; };
		 */
		if (A.name.length() > B.name.length())
			return 1;
		else
			return -1;
	}
}

public class ComparatorEasy {
	public static void main(String[] args) {

		List<Student> s = new ArrayList<Student>();
		s.add(new Student(22, "riya"));
		s.add(new Student(12, "deep"));
		s.add(new Student(21, "monal"));
		s.add(new Student(26, "neha"));

		System.out.println("sort by age using comparator");
		for (int i = 0; i < s.size(); i++) {
			System.out.println(s.get(i));
		}

		System.out.println("sort by num");
		Collections.sort(s, new Student());
		for (int i = 0; i < s.size(); i++) {
			System.out.println(s.get(i));
		}

		System.out.println("sort by name");
		Collections.sort(s, new Sortbyname());
		// Collections.sort(s); //---for comparable it will call compare to method from
		// pojo also in pojo use implement comparable

		for (int i = 0; i < s.size(); i++) {
			System.out.println(s.get(i));
		}

	}

}
