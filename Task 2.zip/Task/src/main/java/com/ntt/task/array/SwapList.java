package com.ntt.task.array;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SwapList {
public static void main(String[] args) {
	List<Integer> list = new ArrayList<>();
	list.add(2);
	list.add(4);
	list.add(6);
	list.add(8);
	list.add(10);
	Collections.swap(list, 2, 4);
	System.out.println("after swap" + list);
}
}
