package com.ntt.task.Udemy.ObjectOrientedProgramming;

import java.math.BigDecimal;

public class SimpleIntersetCalculation {
//simple interst formula
	//Total amount = principal + principal*interest*noOfYear;

	BigDecimal principal;
	BigDecimal interest;

	public SimpleIntersetCalculation(String principal, String interest) {
		this.principal = new BigDecimal(principal);
		this.interest = new BigDecimal(interest);

	}

	public BigDecimal calculateTotalVale(int noOfYears) {
		BigDecimal noOfYearsBigdecimal = new BigDecimal(noOfYears);
		BigDecimal totalValue = principal.add(principal.multiply(interest).multiply(noOfYearsBigdecimal));

		return totalValue;
		// TODO Auto-generated method stub

	}
}
