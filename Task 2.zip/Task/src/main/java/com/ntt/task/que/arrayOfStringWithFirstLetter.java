package com.ntt.task.que;

import lombok.var;

public class arrayOfStringWithFirstLetter {

	public static void main(String[] args) {
		String[] arrayData = { "Deepali", "Jui", "Avni", "Kartik" };

		for (var i = 0; i < arrayData.length; i++) {
			char charAt = arrayData[i].charAt(0);
			System.out.println("-->"+charAt);
			//String string = Character.toString(arrayData[i].charAt(0)); // by using CharAt
			//String string1 = arrayData[i].substring(0, 1); // by using subString
			//System.out.println("character:" + string + " substring:" + string1 + " charAt:" + charAt);
		}	
		// for(String firstLetter : arrayData) {
		// String g=firstLetter.substring(0,1);
	}
}
