package com.ntt.task.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class EmployeeDetails implements Comparable<EmployeeDetails>{

	private String empName;
	private int empAge;
	private double empSalary;
	
	public int compareTo(EmployeeDetails empData){  
		if(this.empAge==empData.empAge)  
		return 0;  
		else if(this.empAge>empData.empAge)  
		return 1;  
		else  
		return -1;  
		}  	
}
