package com.ntt.task.card;

public class Main {
	public static void main(String[] args) {
		Cards card1 = new Cards(Suits.HEARTS, Rank.FOUR);
		Cards card2 = new Cards(Suits.CLUBS, Rank.QUEEN);
		CardComparator c = new CardComparator();
		System.out.println(c.compare(card1, card2));

		System.out.println("------sorting------------");

		DeckOfCards deck = new DeckOfCards();
		System.out.println("shuffle");
		for (Cards card : deck.getCards()) {
			System.out.println("cards>>" + card);
		}
		deck.sortDeck();
		System.out.println("sorted>>");
		for (Cards card : deck.getCards()) {
			System.out.println("sorted cards>>" + card);
		}
	}

}
