package com.ntt.task.designpattern;

public class Subscriber implements Observer{

	@Override
	public void getnotification() {
	System.out.println("Hi harshit you fav youtube deepali upload yoga video");
		
	}
}
