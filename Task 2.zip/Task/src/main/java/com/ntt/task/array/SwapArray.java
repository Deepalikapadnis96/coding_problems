package com.ntt.task.array;

public class SwapArray {
public static void main(String[] args) {
	int[] array= {1,3,6,9,11,13,15};
	int index1=1;
	int index2=3;
			System.out.println("befor swap");
			for(int num: array) {
				System.out.println(num+ " ");
			}
			int temp =array[index1];
			array[index1]=array[index2];
			array[index2]=temp;
			System.out.println("after swap");
			for (int num: array) {
				System.out.println(num+ " ");
			}
}
}
