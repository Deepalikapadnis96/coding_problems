package com.ntt.task.stream;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ReverseWHoleString {
	public static void main(String[] args) {
		System.out.println("===============Reversing whole string ===============");
		String str = "deepali kapadnis in ntt data payment services";
		String reverse = new StringBuilder(str).reverse().toString();
		System.out.println("reverse string>>" + reverse);

		ReverseWHoleString rev = new ReverseWHoleString();
		rev.data();
		rev.data1();
		rev.data2();
		rev.data3();
		rev.data4();
	}

	void data() {
		System.out.println();
		System.out.println("===============count of each word ===============");

		String str = "deepali worked for nttdata as a for backend developer";
		Map<String, Long> collect2 = Arrays.stream(str.split("\\s"))
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.println(collect2);

	}

	void data1() {
		System.out.println();
		System.out.println("===============reverse each words ===============");
		String str = "deepali worked for nttdata as a for backend developer";
		String rev = Arrays.stream(new StringBuilder(str).reverse().toString().split("\\s+"))
				.map(x -> new StringBuilder(x).reverse().toString()).collect(Collectors.joining(" "));
		System.out.println("each word in reverse order >>" + rev);
	}

	void data2() {
		System.out.println();
		System.out.println("===============ASCII ===============");
		String str = "deepali worked for nttdata as a for backend developer";
		String rev = str.chars().mapToObj(x -> (char) x).map(x -> (char) (127 - x)).map(Object::toString)
				.collect(Collectors.joining());
		System.out.println(rev);
	}

	void data3() {
		System.out.println();
		System.out.println("===============sorting according to ASCII (internally ascending order)===============");
		String str = "deepali ";
		String sort = str.chars().filter(Character::isLetter).sorted().mapToObj(x -> (char) x + "::" + x)
				.collect(Collectors.joining(", "));
		System.out.println(">>" + sort);

	}

	void data4() {
		System.out.println();
		System.out.println("===============sorting according to ASCII descending order===============");
		String str = "deepali ";
		String sort = str.chars().filter(Character::isLetter).boxed().sorted((a, b) -> b.compareTo(a))
				.map(x -> (char) (int) x + "::" + x).collect(Collectors.joining(", "));
		System.out.println(">>" + sort);
	}
}
